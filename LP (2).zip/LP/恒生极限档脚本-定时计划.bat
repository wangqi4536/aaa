cd /d E:\stock\LP
cnpm run limit