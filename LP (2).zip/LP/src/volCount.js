

const {calculateTimesVolume} = require('./utils/volume')
const colors = require('colors')
const symbol = "HSI.HK"
//const symbol = "PLTR.US"

const symbolA = "000001.SH"
// 长桥接口类
const { Config, TradeContext,QuoteContext } = require('longport')
let config = Config.fromEnv()
const quoteContext= QuoteContext.new(config)

// 查询当日分时
async function selectIntraday(symbol) {
    const ctx = await quoteContext
    const resp = await ctx.intraday(symbol)
    console.log('股票单日分时：', symbol)
    const intradays = []
    for (let obj of resp) {
        intradays.push(obj.toJSON())
        //console.log(obj.toString())
    }

    return new Promise((resolve) => {
        resolve(intradays)
    });
}


// 计算当日各个时间节点的数据
async function vols() {
    console.error("炒股准则:------------".red)
    console.error("极小量买入, 多次出现，多次买入，，，等下次极小量卖出".red)
    console.error("放量下跌做空，放量上涨做多".red)
    console.error("齿状上升，下跌不做相反趋势".red)
    const HSIIntraday = await selectIntraday(symbol)
    calculateTimesVolume(HSIIntraday, undefined, '恒指 ')

    //const AIntraday = await selectIntraday(symbolA)
    //calculateTimesVolume(AIntraday, undefined, '上证 ')
}

// 每分钟执行一次
setInterval(()=> {
    vols()
}, 30000)
