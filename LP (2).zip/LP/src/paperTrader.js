const fs = require('fs');
const path = require('path');
const cron = require('node-cron');
const longportAPI = require('./longportAPI')
const timeUtils = require('./utils/timeUtils')
const RSIUtil = require('./utils/RSI')
const sound = require('./utils/sound')
const {createDailyFiles} = require('./utils/file')
const { sendWecomText } = require('./utils/wecomBot');
// 获取命令行传入的参数（limit1 或 limit2）
const type = process.argv[2];
//  极限挡交易策略
// 港股全局配置
const CONFIG = {
    switch:  false, // 本地验算与模拟交易开关,false为本地模拟

    symbol: "HSI.HK",
    tradingHours: {
        morning: { start: '09:35', end: '12:00' },
        afternoon: { start: '13:00', end: '15:00' }
    },
    rsiCalculationInterval: 10000, // 10秒
    maxPositionValue: 45000, // 最大持仓金额
    initialCapital: 120000, // 初始资金
    bankruptcyPrice: 0.010, // 爆仓价格
    cooldownPeriod: 6 * 60 * 1000 // 加仓以及减仓的冷却周期 6分钟
};
let timeNum = 0; // 时间计数器  6重置，为一分钟
// 美股全局配置
let USCONFIG = {
    switch:  false, // 本地验算与模拟交易开关,false为本地模拟
    symbol: "QQQ.US",
    qqqData: {currentPrice: 0, prevPrice: 0, changePercent: 0, high: 0, low: 0 , diff: 0, limit: 0},
    limitPerList: [-1.5, -2.0, -2.5],   // 下跌三挡
    preAddTime: [1601, 2125],  // 盘前时间
    addTime1: [2131, 2359], // 盘中时间1
    addTime2: [1, 359], // 盘中时间2
    nightTimeSwitch: false , // 12点警告开关
    pcArr: [], //股价波动列表
    pcArrSwitch: true , // 股价波动警告开关
};

// 美股所有股票数据集合
let USAllMap =  new Map();
let allSymbol = [
    {key: 'GLD.US',name: '黄金ETF'}, {key: 'SLV.US',name: '白银EFT'},
    {key: 'TSLA.US',name: '特斯拉'}, {key: 'NVDA.US',name: '英伟达'},
    {key: 'MSFT.US',name: '微软'}, {key: 'GOOGL.US',name: '谷歌'},{key: 'AVGO.US',name: '博通'},
    {key: 'AAPL.US',name: '苹果'},{key: 'AMZN.US',name: '亚马逊'}, {key: 'META.US',name: 'Meta'}, 
    {key: 'AMD.US',name: 'AMD'},  {key: 'INTC.US',name: '英特尔'}, {key: 'PLTR.US',name: 'PLTR'},
    {key: 'UNH.US',name: '联合健康'}, {key: 'NFLX.US',name: '奈飞'},  {key: 'QCOM.US',name: '高通'},
    {key: 'MU.US',name: '美光'}, {key: 'STX.US',name: '希捷科技'}, {key: 'WDC.US',name: '西部数据'}, 
    {key: 'SNDK.US',name: '闪迪'}, {key: 'RMBS.US',name: 'Rambus'},  
    {key: 'TSM.US',name: '台积电'},{key: 'ASML.US',name: '阿斯麦'}, {key: 'IBM.US',name: 'IBM'},
    {key: 'KO.US',name: '可口可乐'}, {key: 'WMT.US',name: '沃尔玛'},
    {key: 'SMCI.US',name: '超威电脑'}, {key: 'HPQ.US',name: '惠普'}, 
    {key: 'ORCL.US',name: '甲骨文'},{key: 'CRWV.US',name: 'Coreweave'}, 
    {key: 'LLY.US',name: '礼来'}, {key: 'NVO.US',name: '诺和诺德'}, 
    {key: 'JPM.US',name: '摩根大通'},{key: 'BLK.US',name: '贝莱德'}, {key: 'GS.US',name: '高盛'}, 
    {key: 'BABA.US',name: '阿里巴巴'},{key: 'PDD.US',name: '拼多多'},{key: 'BIDU.US',name: '百度'},
    {key: 'CRCL.US',name: 'Circle'}, 
    //  {key: 'DXYZ.US',name: 'DXYZ'},{key: 'MMM.US',name: '3M'},
    ];

allSymbol.forEach(item => {
    item.vols = [] // 添加成交量数组
    item.prices = [] // 添加价格数组
    item.errorNums = 0 // 异常次数
    USAllMap.set(item.key, item)
})

// 全局变量
let account = { sum: 0, money: 0, 'P&L': [], holdings: [] };
let hsiData = { currentPrice: 0, prevPrice: 0, changePercent: 0, high: 0, low: 0 , diff: 0}; //恒指数据， 单日，前一日，幅度，最高，最低,最高与最低差值
let currentDate = new Date().toISOString().split('T')[0].replace(/-/g, '-').slice(2);
let todayDetails = {details: [], 'P&L': 0 };

let threePerList = [1.51]; // 三挡+ 1.5提醒
let timePerList = [1.2] // 三点定律预警
let limitPerList = [1.8, 1.9, 2.0, 2.4]; // 设置极限档位次数3次
let limithigh = [2.65, 3.85]
let NBTypDiff = 1.5 // 牛熊判断差值
let friday12Switch = false; // 周五12点提醒开关
let CBBC = {
    symbol: '',
    type: 0,
    ask: 0.01 // m卖一价格
}; // 今日待操作牛熊证
let task = { // 任务是否开始执行，执行时间
    init: false,
    initTime: 931,
    add: false,
    addTime: [931, 1515],
    reduce: false,
    reduceTime: [1000, 1459],
    reduceProfitRatio: [65, 110, 200, 300], // 对应的盈利比例减仓1/3
    clear: false,
    clearTime: 1520,
    close: false,
    closeTime: 1605
}

// 初始化
function init() {
    try {
        // 判断是否交易日
        //if (!isTradingDay()) return
        ++timeNum;
        if (timeNum > 5) timeNum = 0;
        // 港股开始入口
        checkAndExecuteInit();

        // 美股开始入口
        USCheckAndExecuteInit();

    } catch (error) {
        console.error('程序运行失败:', error);
    }
}

// 校验时间是否在时间区间内
function timeListValid(validTimeList) {
    const timeStr = timeUtils.formatCurrentTime('HH:mm')
    const numericTime = timeStr.replace(":", ""); // "0930"
    const numericValue = parseInt(numericTime, 10); // 930（数字类型）
    return  validTimeList[0] <= numericValue && numericValue <= validTimeList[1]
}

/**
 * 判断当前时间是否为【周五】且【大于11点】
 * @returns {boolean} 满足返回 true，不满足返回 false
 */
function isFridayAfter12() {
  const now = new Date();
  // 5 = 周五
  const isFriday = now.getDay() === 5;
  // 大于 12:00
  const after11 = now.getHours() >= 12;
  return isFriday && after11;
}

async function checkAndExecuteInit() {
    if (!timeListValid(task.addTime) ) return
    currentDate = new Date().toISOString().split('T')[0].replace(/-/g, '-').slice(2);

    // 筛选并交易
    initializeTodayDetails();
}

//筛选对应的今日交易股票代码
async function initializeTodayDetails() {
    
    // 查询恒指实时数据
    const quoteDatas = await longportAPI.quote([CONFIG.symbol])

    // 更新恒指全局数据
    updateHSIData(quoteDatas[0])

    // 最高价，最低价为开盘价格，与实际最高点不符， 矫正limit
    if (hsiData.open === hsiData.high || hsiData.open === hsiData.low) { 
        // 查询分时数据
        const HSIIntradays = await longportAPI.selectIntraday(CONFIG.symbol)
        // 删除开盘一分钟的无效数据
        // HSIIntradays.shift()
        // 提取分时价格
        const intradayPrices = HSIIntradays.map(item => item.price);
        // 计算最大值和最小值
        hsiData.high = Math.max(...intradayPrices);
        hsiData.low = Math.min(...intradayPrices);
        console.log('校正最大最小值：' + hsiData.high + " : " + hsiData.low)
        hsiData.limit =  calculateChangePercent(hsiData.high, hsiData.prevPrice) - calculateChangePercent(hsiData.low, hsiData.prevPrice); //上下价格
        console.log('校正limit：' + hsiData.limit)
    }
    
    if (limithigh.length > 0 && (limithigh[0] <= hsiData.high || limithigh[0] <= Math.abs(hsiData.low))) {
        console.log('指数高于某个固定值，2.7，提醒')
        // 播放闹铃
        sound.playAlarmLoop()
        // 通知企业微信
        sendText('📢港股预警：固定涨跌幅: ' + hsiData.changePercent.toFixed(2) +'%，非档位预警！！！')
        limithigh.shift()
    }

    // 1.1 1.5各提醒一次
    if (threePerList.length > 0) {
        if (hsiData.limit > threePerList[0]) {
            // 选择牛熊证类型
            const type = selectNBType()
            sendText('🔔  港股档位预警：日内涨跌幅: ' + hsiData.limit.toFixed(2) +'%，触发档位提醒！！！')
            // 播放闹铃
            sound.playAlarmLoop()
            buyCBBCs(type, false)
            threePerList.shift()
        }
    }
    //周五12点以后不做多
    if (isFridayAfter12() && !friday12Switch) {
        sendText('🔔  周五利空下午绝对不要做多，周末会爆！！！')
        friday12Switch = true
    }
    // 三点定律预警
    if(timeListValid([1440, 1510]) && timePerList.length > 0 ) {
        let ahigh = hsiData.changePercent - hsiData.low
        if (hsiData.changePercent > 1.05 && ahigh > timePerList[0]) {
            sendText('⏰  港股三点定律预警：日内涨幅: ' + hsiData.limit.toFixed(2) +'%！！！')
            timePerList.shift()
        }
        let bhigh = hsiData.high - hsiData.changePercent
        if (hsiData.changePercent < -1.15 && bhigh > timePerList[0]) {
            sendText('⏰  港股三点定律预警：日内跌幅: ' + hsiData.limit.toFixed(2) +'%！！！')
            timePerList.shift()
        }
    }

    if (limitPerList.length < 1) return false
    //const limit = calculateLimit()
    // 未达到极限档位, 或者档位异常 + 极限偏差值
    if(hsiData.limit < limitPerList[0] || hsiData.high > 5 || hsiData.low < -5) return false
    
    // 选择牛熊证类型
    const type = selectNBType()
    
    // 过滤掉不适合做的
    if (type == 3 && hsiData.low > -0.3  || type == 4 && hsiData.high < 0.3) return false

    // 通知企业微信
    sendText('🚨 港股极限档预警：日内涨跌幅: ' + hsiData.limit.toFixed(2) +'%，触发极限档提醒！！！')
    // 播放闹铃
    sound.playAlarmLoop()
    // 删除其中的极限一个档位
    limitPerList.shift()
    
    //周五12点以后不做多
    if (type == 3 && isFridayAfter12()) return false

    // 购入牛熊
    buyCBBCs(type, true)
    
    return true
}

async function buyCBBCs(type, isbuy) {
    // 计算合适的期权行权价
    const price = calculatePrice(hsiData.changePercent, type)
    console.log("选择牛熊证类型：" + (type == 3? '牛证' : "熊证") + '; 收回价： '+ price)
    
    // 查询牛熊证
    const CBBCs = await longportAPI.searchCBBC(type, price)
    if (CBBCs.length === 0)  return false
    // 取出符合条件交易量最高的股票代码
    console.log('打印需要交易的牛熊证：', JSON.stringify(CBBCs[0]))
    
    // 当前牛熊证
    CBBC = CBBCs[0]
    sendText('⭐ 极限牛熊证代码：' + CBBC.symbol)
    if (!isbuy) return false
    // 购买牛熊证
    longportAPI.tradeCBBC1(CBBC, CBBC.ask, hsiData.limit < 2 ? 10000 : 30000)
    console.log('打印牛熊证剩余极限档'+ limitPerList.toString())
}

// 更新恒指全局数据
async function updateHSIData(data) {
    hsiData.currentPrice = data.lastDone; // 当前价格
    hsiData.open = data.open
    hsiData.prevPrice = data.prevClose // 前一日收盘价
    hsiData.high = calculateChangePercent(data.high, data.prevClose); // 当日最高
    hsiData.low = calculateChangePercent(data.low, data.prevClose); // 当日最低
    hsiData.changePercent = calculateChangePercent(hsiData.currentPrice, data.prevClose);
    hsiData.limit = hsiData.high - hsiData.low; //上下价格差
    console.log(`恒生指数更新: 当前价格=${hsiData.currentPrice}, 涨跌幅=${hsiData.changePercent.toFixed(2)}%`);
    console.log(`恒生 hisData数据: ${JSON.stringify( hsiData)}`);
}

function selectNBType() {
    return hsiData.changePercent - hsiData.low >= NBTypDiff  ? 4 : 3
}

// 计算安全的行权价 2.4%
function calculatePrice(changePercent, type) {
    // 剩余安全距离
    const limitNum = (limitPerList[0] >= 2.35 ?  2.75 : 2.35) - hsiData.limit

    // 处理牛证
    if (type == 3) {
    const limitPercent  = changePercent - limitNum
        return  hsiData.prevPrice * (1 + limitPercent/100) 
    } else { // 处理熊证
        const limitPercent  = changePercent + limitNum
        return  hsiData.prevPrice * (1 + limitPercent/100) 
    }
}

// 美股交易程序
async function USCheckAndExecuteInit() {
    if (!timeListValid([1601, 2359]) && !timeListValid([2, 359])) return
    // 查询所有股票实时数据
    const allDatas = await longportAPI.quote([USCONFIG.symbol, ...(allSymbol.map(i => i.key))])

    // 写个2分钟内异常大涨的股票告警程序
    // 获取所有股票消息的接口，监控协议，投资
    let qqqDatas = allDatas.shift()

    // 获取所有股票数据, 维护一个全局map，key为股票代码，value为一个对象，对象里有一个数组，存储最近60条数据，每条数据包含价格和成交量
    MonitorAllDatas(allDatas)
    
    // 是否在监控时间内
    let isMonitor = false
    // 盘前时间报警
    if (timeListValid(USCONFIG.preAddTime)) {
       updateQQQData(qqqDatas.preMarketQuote)
       isMonitor = true
    }

    if (timeListValid([2126, 2126]) && timeNum == 1) { // 重置警告
        USCONFIG.limitPerList = [-1.5, -2.0, -2.5]
        sound.speak('买入一张0.5价格的QQQ看涨期权，用盒子锁住手机，11点半解开')
    }
    if (timeListValid([2155, 2155]) && timeNum == 1) { // 重置警告
        sound.speak('查看美股7巨头，25分钟多头红线，分析利好，买入看涨期权')
        setTimeout(() => {
            sound.speak('买入一张0.5价格的QQQ看涨期权，用盒子锁住手机，11点半解开')
        }, 1000 * 20)
    }
    // 12点定律警告
    if (timeListValid([2330, 2359]) && !USCONFIG.nightTimeSwitch) { // 重置警告
        sendText('⏰ 纳指12点定律预警！！！')
        USCONFIG.nightTimeSwitch = true
    }

    // 盘中时间报警
    if (timeListValid(USCONFIG.addTime1) || timeListValid(USCONFIG.addTime2)) {
       updateQQQData(qqqDatas)
       isMonitor = true
    }
    
    if (isMonitor && USCONFIG.limitPerList.length > 0  && USCONFIG.qqqData.changePercent <= USCONFIG.limitPerList[0]) {
        console.log('纳指指数高于某个固定值，提醒')
        // 播放闹铃
        sound.playAlarmLoop()
        sendText('🔔 纳指超跌预警：跌幅达 ' + USCONFIG.qqqData.changePercent.toFixed(2) +'%，触发提醒！！！')
        USCONFIG.limitPerList.shift()
    }
}

// 更新纳指全局数据
function updateQQQData(data) {
    USCONFIG.qqqData.currentPrice = data.lastDone; // 当前价格
    USCONFIG.qqqData.prevPrice = data.prevClose // 前一日收盘价
    USCONFIG.qqqData.high = calculateChangePercent(data.high, data.prevClose); // 当日最高
    USCONFIG.qqqData.low = calculateChangePercent(data.low, data.prevClose); // 当日最低
    USCONFIG.qqqData.changePercent = calculateChangePercent(USCONFIG.qqqData.currentPrice, data.prevClose);
    USCONFIG.qqqData.limit = USCONFIG.qqqData.high - USCONFIG.qqqData.low; //上下价格差
    console.log(`纳斯达克100指数更新: 当前价格=${USCONFIG.qqqData.currentPrice}, 涨跌幅=${USCONFIG.qqqData.changePercent.toFixed(2)}%`);
    //console.log(`纳指100 qqqData数据: ${JSON.stringify( USCONFIG.qqqData)}`);

    USCONFIG.pcArr.push(USCONFIG.qqqData.changePercent)
    if (USCONFIG.pcArr.length > 6) {
        const old = USCONFIG.pcArr[USCONFIG.pcArr.length - 6];
        const diff = USCONFIG.qqqData.changePercent - old
        if (Math.abs(diff) >= 0.14 && USCONFIG.pcArrSwitch) {
            USCONFIG.pcArrSwitch = false
            setTimeout(() => {
                USCONFIG.pcArrSwitch = true
            }, 100000)
            console.log('NASDAQ100异常波动：', diff.toFixed(2) +'%')
            sound.speak('警告 纳斯达克100波动异常 ' + diff.toFixed(2) +'%')
            // 异常波动报警
            sendText( '⚠ 纳指异常波动提醒：' + diff.toFixed(2) +'%，触发提醒！！！') 
        }

        return
    }
    

    
}

function sendText(text) {
    sendWecomText(text).then(res => console.log('发送成功：', res))
        .catch(err => console.error('发送失败：', err));
}

function MonitorAllDatas(allDatas) {

    if (timeListValid([2126, 2132])) { // 盘前数据清空，并在盘中初始化
        // 清空USAllMap，并重新初始化
        USAllMap.clear()
        allSymbol.forEach(item1 => {
            item1.vols = [] // 添加成交量数组
            item1.prices = [] // 添加价格数组
            item1.errorNums = 0 // 异常次数
            USAllMap.set(item1.key, item1)
        })
        return
    }
    allDatas.forEach(item => {
        let Quote = timeListValid(USCONFIG.preAddTime) ? item.preMarketQuote : item

        data = USAllMap.get(item.symbol)
        //console.log(`美股 ${data.name} 数据: ${JSON.stringify(Quote)}`);
        // 先加到末尾
        // 成交量是总的成交量，需要修改代码
        data.vols.push(Quote.volume);
        data.prices.push(Quote.lastDone)
        //console.log(`美股 ${data.name} 数据: ${JSON.stringify(data)}`);
        // 超过200个，删除第一个
        if (data.vols.length > 200) {
            data.vols.shift();
            data.prices.shift();
        }
        if (data.vols.length < 61) return  // 时间长了再说，数据量不够还不好判断

        const volsLength = data.vols.length;
        
        if (data.vols.length >= 180) {
            let isUp = [];
            let isDown = [];
            // 监控30分钟单边上涨，每隔5分钟取一次对应价格，每次大于0.1%，并且最后价格相对于30分钟前价格大于1%
            for (let i = volsLength -1; i >= 30; i-=30) {
                const price = data.prices[i]
                const oldPrice = data.prices[i-30]
                isUp.push(price/oldPrice  > 1.001);
                isDown.push(price/oldPrice  < 0.999);
            }
            const pa = ((Quote.lastDone/ data.prices[volsLength-181]-1)*100).toFixed(2)
            if (pa >= 1 && isUp[0] && isUp[1] && isUp[2] && isUp[3] && isUp[4] && isUp[5] ) {
                sendText('🚀🚀  美股30分钟单边涨幅：' + data.name + '，涨幅: ' + pa + '%')
                sound.speak('警告 美股30分钟单边涨幅 ' + data.name + ' 涨幅异常，涨幅: ' + pa + '%')
                data.vols= [];
                data.prices= [];
            }
            if (pa <= -1&& isDown[0] && isDown[1] && isDown[2] && isDown[3] && isDown[4] && isDown[5] ) {
                sendText('🚨🚨  美股30分钟单边跌幅：' + data.name + '，跌幅: ' + pa + '%')
                sound.speak('警告 美股30分钟单边跌幅 ' + data.name + ' 跌幅异常，跌幅: ' + pa + '%')
                data.vols= [];
                data.prices= [];
            }
        }

        // 满足单边上涨, 或者上涨一个点，监控成交量异常
        if ((Quote.lastDone / data.prices[volsLength-7])>1.003
            && (data.prices[volsLength-7] / data.prices[volsLength-13])>1.003
            && (data.prices[volsLength-13] / data.prices[volsLength-19])>1.003 || (Quote.lastDone/ data.prices[volsLength-19])>1.0098 ) {
                const v6 = Quote.volume - data.vols[volsLength-6]
                const v12 = Quote.volume - data.vols[volsLength-12]
                const v18 = Quote.volume - data.vols[volsLength-18]
                const v60 = Quote.volume - data.vols[volsLength-60]
                const pA = ((Quote.lastDone/ data.prices[volsLength-19]-1)*100).toFixed(2)
                if (v6 < 5000) return
                if (v18/v60 > 0.5) {
                    sendText('🔥美股涨幅提醒：' + data.name + '，涨幅: ' + pA + '%')
                    data.vols= [];
                    data.prices= [];
                }
                
                if (v18/v60 > 0.6 && v6 > (v18/6) && v12 > (v18/2)) {
                    sendText('🚀🚀  美股异常涨幅：' + data.name + '，涨幅: ' + pA + '%')
                    sound.speak('警告 美股 ' + data.name + ' 涨幅异常，涨幅: ' + pA + '%')
                }
                
        }
        // 满足单边下跌, 或者上涨一个点，监控成交量异常
        if ((Quote.lastDone / data.prices[volsLength-7])<0.997
            && (data.prices[volsLength-7] / data.prices[volsLength-13])<0.997
            && (data.prices[volsLength-13] / data.prices[volsLength-19])<0.997 || (Quote.lastDone/ data.prices[volsLength-19])<0.9902 ) {
                
                const v6 = Quote.volume - data.vols[volsLength-6]
                const v12 = Quote.volume - data.vols[volsLength-12]
                const v18 = Quote.volume - data.vols[volsLength-18]
                const v60 = Quote.volume - data.vols[volsLength-60]
                const pA = ((1-Quote.lastDone/ data.prices[volsLength-19])*100).toFixed(2)
                if (v6 < 5000) return
                if (v18/v60 > 0.5) {
                    sendText('📉  美股跌幅提醒：' + data.name + '，跌幅: ' + pA + '%')
                    data.vols = [];
                    data.prices = [];
                }
                if (v18/v60 > 0.6 && v6 > (v18/6) && v12 > (v18/2)) {
                    sendText('🚨🚨 美股异常跌幅：' + data.name + '，跌幅: ' + pA+ '%')
                    sound.speak('警告 美股 ' + data.name + ' 跌幅异常，跌幅: ' + pA + '%')
                }
                
        }

    //     let compareVols = []
    //     let comparePrices = []
    //     for (let i = data.vols.length - 7; i >= 0; i -= 6) {
    //         compareVols.push(data.vols[i])
    //         comparePrices.push(data.prices[i])
    //     }
    //     if (compareVols.length < 2) return
    //     const volsSum = compareVols.reduce((prev, curr) => prev + curr, 0);
    //     const volsSumAvg = volsSum / compareVols.length; // 成交量平均值
    //     const pricesSum = comparePrices.reduce((prev, curr) => prev + curr, 0);
    //     const pricesSumAvg = pricesSum / comparePrices.length;
    //     if ((Quote.volume / compareVols[0]) >= 1 && (Quote.volume / volsSumAvg) >= 1 && 
    //     (Math.abs(Quote.lastDone - comparePrices[0]) / comparePrices[0]) > 0.00013 
    //     && (Math.abs(Quote.lastDone - pricesSumAvg) / pricesSumAvg) > (0.00013*(data.errorNums + 1))) { 
    //         ++data.errorNums
    //         if (data.errorNums > 3) {
    //             sendText('⚠️  美股异常涨幅：' + Quote.name + '，涨幅: ' + (Quote.volume / compareVols[0]).toFixed(2) + '倍，成交量: ' + Quote.volume.toLocaleString() + '股，涨幅: ' + (Math.abs(Quote.lastDone - comparePrices[0]) / comparePrices[0]).toFixed(2) + '倍')
    //             sound.speak('警告 美股 ' + Quote.name + ' 涨幅异常，涨幅: ' + (Quote.volume / compareVols[0]).toFixed(2) + '倍')
    //             data.errorNums = 0
    //         }
    //     } else {
    //         data.errorNums > 0 && data.errorNums--
    //     }
    })
}

// 判断是否在交易时间内
function isInTradingHours() {
    const now = new Date();
    const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    
    // 检查是否为交易日（周一至周五）
    const day = now.getDay();
    if (day === 0 || day === 6) return false;
    
    // 检查是否在上午交易时间
    if (currentTime >= CONFIG.tradingHours.morning.start && currentTime <= CONFIG.tradingHours.morning.end) {
        return true;
    }
    
    // 检查是否在下午交易时间
    if (currentTime >= CONFIG.tradingHours.afternoon.start && currentTime <= CONFIG.tradingHours.afternoon.end) {
        return true;
    }
    
    return false;
}

// 判断是否为交易日
function isTradingDay() {
    const now = new Date();
    const day = now.getDay();
    return day >= 1 && day <= 5;
}

// 计算涨跌幅百分比
function calculateChangePercent(current, previous) {
    if (previous === 0) return 0;
    return ((current - previous) / previous) * 100;
}


// 清仓卖出
async function clearSell() {
    // 查询牛熊证价格，低一价位卖出
    const Intradas = await longportAPI.selectIntraday(symbol)
    const nowIntrada = Intradas.pop()
    const sellPrice = nowIntrada.price - 0.001
    if(nowIntrada.price == 0.010) return // 爆仓价格不执行
    // 执行卖出
    executeSell(nowIntrada.symbol, sellPrice, account.holdings[0].volume);
}


// 执行卖出
async function executeSell(symbol, price, volume) {
    try {
        const amount = price * volume;
        
        // 检查是否有足够持仓
        const holdingIndex = account.holdings.findIndex(h => h.symbol === symbol);
        
        if (holdingIndex < 0) {
            console.log(`卖出失败：没有持仓 ${symbol}`);
            return false;
        }
        
        const holding = account.holdings[holdingIndex];
        
        // 检查持仓数量是否足够
        if (volume >= holding.volume) {
            console.log(`卖出失败：持仓不足，需要 ${volume}，实际 ${holding.volume}`);
            return false;
        }
        
        // 更新账户
        account.money += amount;
        
        if (volume === holding.volume) {
            // 全部卖出
            account.holdings.splice(holdingIndex, 1);
        } else {
            // 部分卖出
            account.holdings[holdingIndex].volume -= volume;
        }
        
        // 更新总资产
        updateAccountSum();
        
        // 记录交易
        recordTransaction('SELL', symbol, price, volume);
        
        console.log(`卖出成功：${symbol}，价格：${price}，数量：${volume}，金额：${amount}`);
        return true;
    } catch (error) {
        console.error('执行卖出失败:', error);
        return false;
    }
}


// 记录交易
function recordTransaction(side, symbol, price, volume) {
    const turnover = price * volume;
    const timeStr = new Date().toISOString();
    
    todayDetails.details.push({
        symbol,
        side,
        price,
        timestamp: new Date().getTime(),
        timeStr,
        volume,
        turnover
    });
    
    // 保存交易详情
    saveTodayDetails();
}


// 保存账户数据
function saveAccountData() {
    try {
        const filePath = path.join(__dirname, 'account.json');
        fs.writeFileSync(filePath, JSON.stringify(account, null, 2));
    } catch (error) {
        console.error('保存账户数据失败:', error);
    }
}

// 保存今日交易详情
async function saveTodayDetails() {
    try {
        const filePath = path.join(__dirname, `detail-${currentDate}.json`);
        fs.writeFileSync(filePath, JSON.stringify(todayDetails, null, 2));
    } catch (error) {
        console.error('保存今日交易详情失败:', error);
    }
}

// 尾盘任务
async function executeCloseRecord() {

    const HSIIntraday = await longportAPI.selectIntraday("HSI.HK")

    // 创建当日的恒生指数分时文件
    createDailyFiles("HSI.HK", HSIIntraday)

    // 更新总市值
    // updateAccountSum()
    // 保存账号数据
    saveAccountData()

    // 重置全局变量，留第二天继续使用
    account = { sum: 0, money: 0, 'P&L': [], holdings: [] };
    hsiData = { currentPrice: 0, prevPrice: 0, changePercent: 0, high: 0, low: 0, open: 0 }; //恒指数据， 单日，前一日，幅度，最高，最低
    rsiData = { details: [] };
    currentDate = new Date().toISOString().split('T')[0].replace(/-/g, '-').slice(2);
    todayDetails = {details: [], 'P&L': 0 };
    rsiValues = []; // 存储最近的RSI值用于计算

    threePerList = [1.51]; // 三挡+ 1.5提醒
    timePerList = [1.2] // 三点定律预警
    limitPerList = [1.8, 1.9, 2.0, 2.4]; // 设置极限档位次数3次
    limithigh = [2.65, 3.85]
    friday12Switch = false;
    CBBC = {
        symbol: '',
        type: 0,
        ask: 0.01 // 买一价格
    }; // 今日待操作牛熊证
    task = { // 任务是否开始执行，执行时间
        init: false,
        initTime: 931,
        add: false,
        addTime: [931, 1459],
        reduce: false,
        reduceTime: [1000, 1505],
        reduceProfitRatio: [65, 110, 200, 300], // 对应的盈利比例减仓1/3
        clear: false,
        clearTime: 1520,
        close: false,
        closeTime: 1605
    }

    USCONFIG = {
        switch:  false, // 本地验算与模拟交易开关,false为本地模拟
        symbol: "QQQ.US",
        qqqData: {currentPrice: 0, prevPrice: 0, changePercent: 0, high: 0, low: 0 , diff: 0, limit: 0},
        limitPerList: [-1.5, -2.0, -2.5],   // 下跌三挡
        preAddTime: [1601, 2125],  // 盘前时间
        addTime1: [2131, 2359], // 盘中时间1
        addTime2: [1, 359], // 盘中时间2
        nightTimeSwitch: false,
        friday12Switch: false
    };

    console.log('今日收盘')
}


console.log(`软件开始运行，发财，发财，发财`);
console.log(type)
setInterval(() => {
    console.log(`当前时间：${(new Date())}`);
}, 60 * 10 * 1000); 


// 每天早上9:45执行，下午4:10停止
let cronTask;

let test = false

const timeStr = timeUtils.formatCurrentTime('HH:mm').split(":")
// 启动任务
let startTime = '32 09 * * 1-5'; // 09:57
if (type == 'limit2') {
    const timeStr = timeUtils.formatCurrentTime('HH:mm').split(":")
    startTime = Number(timeStr[1]) + 1  + " " + timeStr[0] +  ' * * 0-6'; // 09:57
}
// 停止任务
let endTime = '58 23 * * 1-5'; // 15:30

// 立马执行，与停止
if (test) {
    console.log('纯测试执行代码')
    task.addTime = [130, 2330]
    limitPerList = [1.0, 1.2, 2.4]; // 设置极限档位次数3次
    NBTypDiff = limitPerList[0]
    startTime = Number(timeStr[1]) + 1  + " " + timeStr[0] +  ' * * 0-6'; // 09:57
    endTime = Number(timeStr[1]) + 13  + " " + timeStr[0]  + ' * * 0-6'; // 16:10
    console.log(startTime)
    console.log(endTime)
}
if (test) init()
cron.schedule(startTime, () => {
    console.log('启动定时任务');
     cronTask = setInterval(() => {
        console.log(`🔄 任务执行 - ${new Date().toLocaleTimeString()}`);
        init()
    }, 10000); // 10秒 = 10000毫秒
});

cron.schedule(endTime, () => {
    executeCloseRecord()
    console.log('停止定时任务');
    clearInterval(cronTask);
});
