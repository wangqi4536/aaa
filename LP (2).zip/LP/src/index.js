const {getMessge} = require('./utils/help')
const {selectIntraday} = require('./utils/select')
const {createDailyFiles} = require('./utils/file')
const longportAPI = require('./longportAPI')
const cron = require('node-cron')
const { sendWecomText } = require('./utils/wecomBot');
console.log(getMessge())
//const symbol = "HSI.HK"
const symbol = 'QQQ.US'


const { Config, TradeContext,QuoteContext, NaiveDate } = require('longport')
let config = Config.fromEnv()
// Init config without ENV
// let config = new Config({ appKey: "YOUR_APP_KEY", appSecret: "YOUR_APP_SECRET", accessToken: "YOUR_ACCESS_TOKEN" })
TradeContext.new(config)
  .then((ctx) => ctx.accountBalance())
  .then((resp) => {
    console.log('开始打印长桥数据')
    for (let obj of resp) {
      console.log(obj.toString())
    }
  })
const context= QuoteContext.new(config)
context.then((ctx) => ctx.quote([symbol]))
  .then((resp) => {
    console.log('恒生指数实时行情')
    for (let obj of resp) {
      console.log(obj.toString())
    }
  })

// context.then((ctx) => ctx.intraday(symbol))
//   .then((resp) => {
//     console.log('恒生指数单日分时')
//     for (let obj of resp) {
//       console.log(obj.toString())
//     }
//   })

async function createHSIFile() {
  const HSIIntraday = await selectIntraday(symbol)

  // 创建当日的恒生指数分时文件
  createDailyFiles(symbol, HSIIntraday)
}


// 选择股票
async function selectStocks(type) {
    const ctx = await context
    const resp = await ctx.warrantList("HSI.HK", 0, 1, [type],[],[],[], [2]) // 3,牛，4，熊
    console.log('打印期权')
    const list = []
    resp.forEach(item => {
        const stock = item.toJSON()
        // 过滤掉可能爆仓股票
        if (stock.last_done <= 0.025) return
        list.push(stock)
    })
    const arr = list.sort((a, b) => b.turnover - a.turnover).slice(0, 1)
    
    for (let obj of arr) {
      console.log(JSON.stringify(obj))
    }
    return new Promise((resolve) => {
        resolve(arr)
    });
}

// 打印期权分时
async function createHSIFile2() {
  const symbols = await selectStocks(4)
  const HSIIntraday = await selectIntraday(symbols[0].symbol)
  // 创建当日的恒生指数分时文件
  createDailyFiles(symbols[0].symbol, HSIIntraday)
}
//createHSIFile()
//createHSIFile2()
longportAPI.tradingSessionHK()

// 每天早上9:45执行，下午4:10停止
let task;

// 启动任务
let startTime = '29 09 * * 1-5'; // 09:57
// 停止任务
let endTime = '30 15 * * 1-5'; // 16:10

// 立马执行，与停止
// startTime = '10 20 * * 1-7'; // 09:57
// endTime = '11 20 * * 1-7'; // 16:10

// cron.schedule(startTime, () => {
//   console.log('启动定时任务');
//   task = cron.schedule('*/1 * * * *', () => { // 每分钟执行一次
//     console.log('执行任务...');
//   });
// });


// cron.schedule(endTime, () => {
//   console.log('停止定时任务');
//   task.stop();
// });

// 查询美股期权
async function usQu(symbol) {

  //let config1 = Config.fromEnv()
   QuoteContext.new(config)
      .then((ctx) => ctx.optionChainInfoByDate("QQQ.US", new NaiveDate(2026, 3, 31)))
      .then((resp) => {
        for (let obj of resp) {
          //console.log(obj.toString())
        }
  })
 // const deRsp = await context.optionChainInfoByDate(symbol)
 // console.log('打印期权', deRsp.toString())
}
// 查询卖一价格
// 选择股票
async function selectBuyPrice(symbol) {

  //  * const { Config, QuoteContext } = require("longport")
  //  *
  //  * let config = Config.fromEnv()
  //  * QuoteContext.new(config)
  //  *   .then((ctx) => ctx.depth("700.HK"))
  //  *   .then((resp) => console.log(resp.toString()))
 // let config2 = Config.fromEnv()
   QuoteContext.new(config)
      .then((ctx) => ctx.optionQuote([symbol]))
      .then((resp) => console.log(resp.toString()))
  QuoteContext.new(config)
      .then((ctx) => ctx.depth(symbol))
      .then((resp) => console.log(resp.toString()))
}
usQu("QQQ.US")
//selectBuyPrice('QQQ260409P596000.US')

const { speak } = require('./utils/sound');
//speak('警告 纳斯达克100波动异常 ' + 0.14 +'%')

speak('美股开盘，10点做多纳指, 12点收盘，昏头立马止损')

// 直接调用
// sendWecomText('🚨 港股预警：当前涨跌幅达 1.1%，已临近第三档1.2%！')
//   .then(res => console.log('发送成功：', res))
//   .catch(err => console.error('发送失败：', err));