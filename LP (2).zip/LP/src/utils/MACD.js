// 计算 EMA（指数移动平均线）
function calculateEMA(data, period) {
  if (data.length < period) return null;
  const sma = data.slice(0, period).reduce((acc, val) => acc + val, 0) / period;
  const ema = data.slice().map((price, index) => {
    if (index < period) return sma; // 前 period 项用 SMA 初始化
    const multiplier = 2 / (period + 1);
    return price * multiplier + ema[index - 1] * (1 - multiplier);
  });
  return ema[ema.length - 1]; // 返回最新 EMA 值
}

// 计算 MACD
function calculateMACD(prices, fastPeriod = 12, slowPeriod = 26, signalPeriod = 9) {
  if (prices.length < slowPeriod) return null; // 至少需要 slowPeriod 数据
  
  const fastEMA = calculateEMA(prices, fastPeriod);
  const slowEMA = calculateEMA(prices, slowPeriod);
  const macdLine = fastEMA - slowEMA; // MACD 线
  
  // 计算信号线（MACD 线的 EMA）
  const macdHistory = [];
  for (let i = slowPeriod - 1; i >= 0; i--) { // 构造 MACD 历史数据（长度需满足 signalPeriod）
    const emaFast = calculateEMA(prices.slice(0, i + 1), fastPeriod);
    const emaSlow = calculateEMA(prices.slice(0, i + 1), slowPeriod);
    macdHistory.unshift(emaFast - emaSlow);
  }
  const signalLine = calculateEMA(macdHistory, signalPeriod); // 信号线
  
  return {
    macd: macdLine,
    signal: signalLine,
    histogram: macdLine - signalLine // 柱状图
  };
}