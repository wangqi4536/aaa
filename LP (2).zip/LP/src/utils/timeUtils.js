const { format } = require('date-fns');

// 获取当前对应格式的时间
function formatCurrentTime(temple) {
    const now = new Date();
    return format(now, temple || 'yy-M-d'); // 如 "24-6-4"
}


// 转换时间格式
function formatTime(time, temple) {
    return format(time, temple || 'yy-M-d'); // 如 "24-6-4： 'HH:mm"
}

exports.formatCurrentTime = formatCurrentTime
exports.formatTime = formatTime
