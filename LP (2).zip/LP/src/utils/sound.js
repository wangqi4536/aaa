const player = require('play-sound')({});
const path = require('path');
const { exec } = require('child_process');
const readline = require('readline');

/**
 * 立即播放闹铃声音（调用后马上响）
 * @param {string} customSoundPath - 自定义音频路径（可选，不传则用系统提示音）
 */
function playAlarmImmediately(customSoundPath = null) {
  console.log('🔔 闹铃立即播放！');

  // 方案1：播放自定义音频文件（优先推荐，声音更自定义）
  if (customSoundPath) {
    player.play(path.resolve(__dirname, customSoundPath), (err) => {
      if (err) {
        console.error('自定义音频播放失败，切换到系统提示音:', err);
        playSystemSound(); // 失败则降级播放系统音
      }
    });
  } else {
    // 方案2：无自定义音频时，播放系统自带提示音（跨系统兼容）
    playSystemSound();
  }
}

// 播放系统自带提示音（无需额外文件）
function playSystemSound() {
  switch (process.platform) {
    case 'win32': // Windows
      exec('powershell -c (New-Object Media.SoundPlayer "C:\\Windows\\Media\\money.wav").PlaySync()');
      //exec(`powershell -c Start-Process -FilePath wmplayer.exe -ArgumentList "${audioPath}", "/play", "/close"`)
      break;
    case 'darwin': // macOS
      exec('afplay /System/Library/Sounds/Hero.aiff');
      break;
    case 'linux': // Linux
      exec('aplay /usr/share/sounds/alsa/Front_Center.wav');
      break;
    default:
      console.error('暂不支持当前系统的系统提示音');
  }
}

// 循环播放闹铃，直到手动按 Ctrl+C 终止
exports.playAlarmLoop = function playAlarmLoop(str) {
  playAlarmImmediately(str);; // 立即播放第一次
  // 每75秒重复一次
  const loopTimer = setInterval(() => {
    playAlarmImmediately(str);
  }, 75000);

  // 关闭终端行缓冲，直接捕获按键（无需按Enter）
  readline.emitKeypressEvents(process.stdin);
  if (process.stdin.isTTY) {
    process.stdin.setRawMode(true); // 关键：开启原始模式
  }

  // ========== 修复后的 Ctrl+A 监听 ==========
  process.stdin.on('keypress', (str, key) => {
    // 方式1：捕获 Ctrl+A（兼容所有终端）
    if (key.ctrl && key.name === 'a') {
      clearInterval(loopTimer);
      console.log('\n🛑 闹铃已停止');
      process.stdin.setRawMode(false); // 恢复终端默认模式
      //process.exit(0);
    }
  });
}

// 系统声音
exports.speak = function speak(text) {
  exec(`powershell -Command "Add-Type -AssemblyName System.Speech; $voice = New-Object System.Speech.Synthesis.SpeechSynthesizer; $voice.SelectVoice('Microsoft Huihui Desktop'); $voice.Speak('${text}');"`);
}