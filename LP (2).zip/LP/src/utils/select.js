
const { Config, TradeContext,QuoteContext } = require('longport')
let config = Config.fromEnv()
const context= QuoteContext.new(config)
// 查询当日分时
exports.selectIntraday  = async function selectIntraday(symbol) {
    const ctx = await context
    const resp = await ctx.intraday(symbol)
    console.log('股票单日分时：', symbol)
    const intradays = []
    for (let obj of resp) {
        intradays.push(JSON.stringify(obj.toJSON()))
        console.log(obj.toString())
    }

    return new Promise((resolve) => {
        resolve(intradays)
    });
}