// 计算成交量柱状图（收盘价上涨为绿色，下跌为红色）
function calculateVolumeBars(prices, volumes) {
  const bars = [];
  for (let i = 0; i < prices.length; i++) {
    const isUp = i > 0 ? prices[i] >= prices[i - 1] : true;
    bars.push({
      volume: volumes[i],
      color: isUp ? 'green' : 'red',
      date: new Date().toISOString().split('T')[0] // 示例日期，实际应使用真实时间序列
    });
  }
  return bars;
}