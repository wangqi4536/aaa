// 股票RSI计算函数

exports.calculateRSI2 = function calculateRSI2(prices, period = 14) {
  if (prices.length < period + 1) return null;
  
  const gains = [];
  const losses = [];
  
  for (let i = 1; i < prices.length; i++) {
    const change = prices[i] - prices[i-1];
    if (change > 0) {
      gains.push(change);
      losses.push(0);
    } else {
      gains.push(0);
      losses.push(-change);
    }
  }
  
  const avgGain = calculateSMA(gains.slice(-period), period); // 复用 SMA 函数
  const avgLoss = calculateSMA(losses.slice(-period), period);
  
  if (avgLoss === 0) return 100; // 避免除数为0
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}

/**
 * 计算RSI (相对强弱指标) - 标准Wilder实现（主流券商通用算法）
 * @param {Array<number>} prices - 价格数组，按时间升序排列
 * @param {number} period - RSI计算周期，通常为14
 * @returns {Array<number>} - RSI值数组，前`period`个元素为null
 */
exports.calculateRSI = function calculateRSI(prices, period = 12) {
    if (prices.length < period + 1) {
        throw new Error(`计算RSI需要至少${period + 1}个价格数据点`);
    }

    const rsiValues = new Array(prices.length).fill(null);
    let avgGain = 0;
    let avgLoss = 0;

    // 计算初始平均收益和损失（前period个变动）
    for (let i = 1; i <= period; i++) {
        const change = prices[i] - prices[i - 1];
        avgGain += change > 0 ? change : 0;
        avgLoss += change < 0 ? -change : 0;
    }
    avgGain /= period;
    avgLoss /= period;

    // 计算第一个RSI值
    const firstRS = avgLoss === 0 ? Infinity : avgGain / avgLoss;
    rsiValues[period] = 100 - (100 / (1 + firstRS));

    // 使用Wilder平滑法计算后续RSI值
    for (let i = period + 1; i < prices.length; i++) {
        const change = prices[i] - prices[i - 1];
        const currentGain = change > 0 ? change : 0;
        const currentLoss = change < 0 ? -change : 0;

        // Wilder平滑公式：新平均值 = (旧平均值 * (period-1) + 新值) / period
        avgGain = (avgGain * (period - 1) + currentGain) / period;
        avgLoss = (avgLoss * (period - 1) + currentLoss) / period;

        const rs = avgLoss === 0 ? Infinity : avgGain / avgLoss;
        rsiValues[i] = 100 - (100 / (1 + rs));
    }

    return rsiValues;
}