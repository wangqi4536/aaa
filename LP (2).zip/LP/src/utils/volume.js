// 成交量辅助计算工具
const colors = require('colors')
// 时间点配置
const timePoints = [
    11, //'09:40', 
    31, //'10:00', 
    61, //'10:30', 
    91, //'11:00', 
    121, //'11:30', 
    151, //'13:00', 
    181, //'13:30', 
    241, //'14:30', 
    331, //'16:00'
];

// 时间点映射表
const timePointStrs = {
    11: '09:40', 
    31: '10:00', 
    61: '10:30', 
    91: '11:00', 
    121: '11:30', 
    151: '13:00', 
    181: '13:30', 
    241: '14:30', 
    331: '实时'
};
// 计算各个时间节点成交量并输出结果
exports.calculateTimesVolume  = function calculateTimesVolume(data, times = timePoints, str) {
    const totalVolumes = []
    times.forEach(time => {
        // 小于等于当前次数时，不计算
        if (data.length <= time && time !== 331) return
        const totalVolume = data.slice(0, time)
            .reduce((sum, item) => sum + item.volume, 0);
        
        const total = data.slice(0, time)
            .reduce((sum, item) => sum + Number(item.turnover), 0);
        const te =  str+ timePointStrs[time]+" 总成交量: " + totalVolume/100000000 + '亿股；'
            + " 总成交额: " + total/100000000 + '亿元'
        console.log(te.yellow
        )
        totalVolumes.push(totalVolume)
    });
}