
const fs = require('fs').promises;
const path = require('path');
const { format } = require('date-fns');

// 确保目录存在（递归创建）
async function ensureDir(dirPath) {
  try {
    await fs.mkdir(dirPath, { recursive: true });
  } catch (err) {
    if (err.code !== 'EEXIST') throw err;
  }
}


// 主函数
async function createDailyFiles(symbol, list) {
  try {
    // 获取当前日期并格式化为 "YY-M-D"
    const now = new Date();
    const dateStr = format(now, 'yy-M-d'); // 如 "24-6-4"
    
    // 创建以日期命名的文件夹
    const dirName = path.join(__dirname, "../../file/"+dateStr);
    await ensureDir(dirName);
    //console.log('需要写入的文件详情', JSON.stringify(list))
    
    // 写入 JSON 文件
    await fs.writeFile(
      path.join(dirName, symbol + '.json'),
      JSON.stringify(list, null, 2)
    );
    
    console.log(`✅ 文件夹 "${dateStr}" 及文件创建成功`);
  } catch (err) {
    console.error('❌ 操作失败:', err);
  }
}
exports.createDailyFiles = createDailyFiles