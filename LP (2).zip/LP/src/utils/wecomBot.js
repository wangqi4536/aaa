// wecomBot.js - 企业微信机器人纯文本发送工具
const https = require('https');

/**
 * 发送企业微信纯文本消息
 * @param {string} content 消息内容
 * @returns {Promise} 发送结果
 */
function sendWecomText(content) {
  return new Promise((resolve, reject) => {
    // 你的 Webhook 地址
    const webhookUrl = 'https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=d91fef59-7aa0-4493-8a7b-6e95b6690ba1';

    // 构造消息体（标准格式，微信可显示）
    const postData = JSON.stringify({
      msgtype: 'text',
      text: {
        content: content
      }
    });

    // 解析 URL
    const url = new URL(webhookUrl);

    const options = {
      hostname: url.hostname,
      path: url.pathname + url.search,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
      }
    };

    // 发送请求
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => {
        try {
          const result = JSON.parse(data);
          resolve(result);
        } catch (err) {
          resolve(data);
        }
      });
    });

    req.on('error', (e) => {
      reject(e);
    });

    req.write(postData);
    req.end();
  });
}

// 导出方法
module.exports = { sendWecomText };