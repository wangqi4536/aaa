// 生成K线数据（从逐笔交易记录聚合为K线）
function generateCandlestickData(trades, timeframe = '1m') {
  const candlesticks = [];
  let currentCandle = null;
  
  // 时间周期转换函数（示例：'1m' → 60000毫秒）
  const timeframeToMs = {
    '1m': 60 * 1000,
    '5m': 5 * 60 * 1000,
    '1h': 60 * 60 * 1000,
    '1d': 24 * 60 * 60 * 1000
  };
  
  const interval = timeframeToMs[timeframe] || 60000;
  
  trades.forEach(trade => {
    const timestamp = new Date(trade.timestamp).getTime();
    
    // 计算当前交易所属的K线时间戳（按interval取整）
    const candleTimestamp = new Date(Math.floor(timestamp / interval) * interval);
    
    // 如果是新的K线周期，创建新K线
    if (!currentCandle || candleTimestamp > new Date(currentCandle.timestamp)) {
      if (currentCandle) {
        candlesticks.push(currentCandle);
      }
      
      currentCandle = {
        timestamp: candleTimestamp.toISOString(),
        open: trade.price,
        high: trade.price,
        low: trade.price,
        close: trade.price,
        volume: trade.volume
      };
    } else {
      // 更新当前K线数据
      currentCandle.high = Math.max(currentCandle.high, trade.price);
      currentCandle.low = Math.min(currentCandle.low, trade.price);
      currentCandle.close = trade.price;
      currentCandle.volume += trade.volume;
    }
  });
  
  // 添加最后一根K线
  if (currentCandle) {
    candlesticks.push(currentCandle);
  }
  
  return candlesticks;
}


// 判断K线形态（简单示例：判断是否为锤子线）
function isHammer(candle) {
  const body = Math.abs(candle.close - candle.open);
  const upperShadow = candle.high - Math.max(candle.open, candle.close);
  const lowerShadow = Math.min(candle.open, candle.close) - candle.low;
  
  // 锤子线条件：下影线至少是实体的2倍，上影线很短，实体在顶部
  return lowerShadow >= body * 2 && upperShadow <= body * 0.1 && 
         ((candle.close > candle.open && lowerShadow >= (candle.high - candle.open) * 0.6) ||
          (candle.open > candle.close && lowerShadow >= (candle.high - candle.close) * 0.6));
}
