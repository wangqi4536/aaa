
// 使用方法
const calculateRSI = require('./RSI'); // 引入整个模块
const { Config, TradeContext,QuoteContext } = require('longport')
let config = Config.fromEnv()
const context= QuoteContext.new(config)
const symbol = "HSI.HK" // 恒生指数code

let RSIArr = [] // RSI根据时间存储的数据，每分钟一条
let buyPoint = false // 买入点
let heldStocks = [] // 持仓股
exports.trade = () => {
    // 后边加定时器，一分钟循环一次
    const time =0;
    // 时间在10点以后到4点之间，如果股票没有持仓，就执行对应操作，如果有持仓，并亏损，则尝试加成
    if (!allowTradeTime) return

    // 查询一次单日期权，价差在1-2个点以上，成交量大的，溢价相对较低的补充进入持仓股

    const RSI = calculateRSI() //计算当前RSI数据 todo待补充参数
    RSIArr.push(RSI)
    // 当前价格
    const currentPrice = 10
    const prev_close = 11
    //1分钟尝试一次建仓
    const pricePC = pricePercent(currentPrice, prev_close)
    // 执行算法   在股票价格+0.55以上买入  （RSI指标满足>80后下跌） 
    if (pricePC > 0.0055 ) {
        
    }
    // -0.55以下买入（RSI指标满足< 20后上升）
    if (pricePC < -0.0055) {

    }
}


// 计算价格变化的百分比偏差(当前价格， 昨日收盘价格)
function pricePercent(current, prev_close) {
     return (current - prev_close) / prev_close
}

// 交易时间区间
function allowTradeTime() {
    const now = new Date();
    const day = now.getDay(); // 0 (周日) 到 6 (周六)
    const hour = now.getHours();

    // 检查是否为工作日 (周一到周五)
    const isWeekday = day >= 1 && day <= 5;
    
    // 检查是否在 10:00 到 16:00 之间 (不包含 16:00)
    const isWithinHours = hour >= 10 && hour < 16;

    return isWeekday && isWithinHours;
}

// 选择股票
function selectStocks() {
    resp = ctx.warrant_list("HSI.HK", WarrantSortBy.LastDone, SortOrderType.Ascending)
    context.then((ctx) => ctx.warrant_list(symbol, 0, 1, [2,3],[],[],[], 2 ))
    .then((resp) => {
        console.log('恒生指数实时行情')
        for (let obj of resp) {
        console.log(obj.toString())
        }
    })
}

// 股票买入
function buyStock(stockSymbol, num, price) {
    // 买盘，卖盘先不写，先用高一档买入，第一档卖出计算，市价单逻辑
    context.then((ctx) => ctx.submitOrder({
      symbol: stockSymbol,
      orderType: 'MO',// ELO	增强限价单 MO	市价单
      side: 'Buy',   // Buy - 买入 Sell - 卖出
      timeInForce: TimeInForceType.Day,
      submittedQuantity: 200,
      submittedPrice: new Decimal("300"), // 买入价格
    }))
    .then((resp) => {
        console.log(resp.toString())
    })
}

// 股票卖出
function sellStock(stockSymbol, num, price) {
    // 买盘，卖盘先不写，先用高一档买入，第一档卖出计算， 市价单逻辑
    context.then((ctx) => ctx.submitOrder({
      symbol: stockSymbol,
      orderType: 'MO',// ELO	增强限价单 MO	市价单
      side: 'Sell',   // Buy - 买入 Sell - 卖出
      timeInForce: TimeInForceType.Day,
      submittedQuantity: 200, // 下单数量，例如：100
      submittedPrice: new Decimal("300"), // 买入价格
    }))
    .then((resp) => {
        console.log(resp.toString())
    })
}

// 查询股票行情
function selectStock(stockSymbol) {
    context.then((ctx) => ctx.warrantQuote([stockSymbol]))
    .then((resp) => {
        console.log(resp.toString())
    })
}

// 获取股票的盘口
function selectDepth(stockSymbol) {
context.then((ctx) => ctx.depth(stockSymbol))
    .then((resp) => {
        console.log(resp.toString())
    })
}

