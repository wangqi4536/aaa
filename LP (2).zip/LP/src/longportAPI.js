
// 长桥接口类
const { Config, TradeContext,QuoteContext, OrderType, OrderSide, TimeInForceType, Decimal } = require('longport')
let config = Config.fromEnv()
const quoteContext= QuoteContext.new(config)
const tradeContext = TradeContext.new(config)

// 信息查询类
async function quoteContextReq() {
    const ctx = await quoteContext
    return ctx
}

// 交易类
async function tradeContextReqReq() {
    const ctx = await quoteContext
    return ctx
}

// 获取港股市场交易时间
async function tradingSessionHK() {
    const ctx = await quoteContext
    const resp = await ctx.tradingSession()
    console.log('获取港股市场交易时间')
    for (let obj of resp) {
        const session = obj.toJSON()
        if (session.market == "HK") {
            return new Promise((resolve) => {
                console.log('交易时间', JSON.stringify(session))
                resolve(session.tradeSession)
            });
        }
    }
    // 无交易时间返回空数组
    return new Promise((resolve) => {
        resolve([])
    });
}

// 获取账户资金
async function accountBalance() {
    const ctx = await tradeContext
    const resp = await ctx.accountBalance()
    console.log('获取账户资金')
    const list = []
    for (let obj of resp) {
        list.push(obj.toJSON())
        console.log(obj.toString())
    }
    return new Promise((resolve) => {
        resolve(list)
    });
}
// 获取持仓股票
async function stockPositions() {
    const ctx = await tradeContext
    const resp = await ctx.stockPositions()
    console.log('获取持仓股票')
    console.log(resp.toString())
    return new Promise((resolve) => {
        resolve(resp.toJSON())
    });
}

// 查询标的实时行情
async function quote(symbol) {
    const ctx = await quoteContext
    const resp = await ctx.quote(symbol)
    //console.log('指数实时行情')
    const list = []
    for (let obj of resp) {
        list.push(obj.toJSON())
        //console.log(obj.toString())
    }
    return new Promise((resolve) => {
        resolve(list)
    });
}
// 查询当日分时
async function selectIntraday(symbol) {
    const ctx = await quoteContext
    const resp = await ctx.intraday(symbol)
    console.log('股票单日分时：', symbol)
    const intradays = []
    for (let obj of resp) {
        intradays.push(obj.toJSON())
        //console.log(obj.toString())
    }

    return new Promise((resolve) => {
        resolve(intradays)
    });
}
// 打印牛熊证详情
function CBBCPrint(CBBCs) {
    console.log('牛熊证数量：',CBBCs.length)
    if (CBBCs.length) {
        const CBBCsDetail = []
        CBBCs.forEach(item => {
            const stock = item.toJSON()
            CBBCsDetail.push("id:" + stock.symbol + ";价格"+  stock.lastDone + '值:', stock.strikePrice) 
        })
        console.log(CBBCsDetail.toString())
    }
}

// 查询恒生指数牛熊证
async function searchCBBC(type, price) {
    const ctx = await quoteContext
    const resp = await ctx.warrantList("HSI.HK", 3, 1, [type],[],[],[], [2]) // 3,牛，4，熊
    //CBBCPrint(resp)
    const symbolArr = resp.slice(0, 80).map(item => item.symbol)
    // 基于成交量排序, 选择成交量高volume的40个，然后选杠杆比率最高的3个 leverage_ratio，顺便读取标的盘口 Config.from_env()，查询卖一价格
    // 对比3个卖一价格谁最低买谁
    // 查询牛熊证详情
    const resp1 = await ctx.warrantQuote(symbolArr)
    //console.log(JSON.stringify(resp1[0]))
    const list = []
    resp1.forEach(item => {
        const stock = item.toJSON()
        //console.log('strikePrice : '+  stock.strikePrice.toNumber() +"; lastDone" + stock.lastDone.toNumber() + "; leverageRatio" + stock.leverageRatio.toNumber())
        //console.log(JSON.stringify(stock))
        // 打印 strikePrice、price、lastDone 的类型和值
        //console.log('strikePrice 类型:', typeof stock.strikePrice, '值:', stock.strikePrice)
        //console.log('price 类型:', typeof price, '值:', price)
        //console.log('lastDone 类型:', typeof stock.lastDone, '值:', stock.lastDone)
        // 过滤掉不符合安全的票
        if (type === 3) {
            // 牛证的行权价>安全价格过滤
            if (Number(stock.callPrice) >= price) return
        } else {
            // 熊证的行权价<安全价格过滤
            if (stock.callPrice <= price) return
        }
        
        // 过滤掉可能爆仓股票,过滤50000倍的,成交量极低的
        if (stock.lastDone <= 0.011 || stock.lastDone >=0.090  || stock.conversionRatio > 20000 || stock.volume < 35000000) return
        list.push(stock)
    })
    console.log(JSON.stringify(list[0]))
    const arr2 = list.sort((a, b) => {
        let leverageRatio1 =  (a.strikePrice / a.conversionRatio) / a.lastDone
        //console.log('杠杆比率1：'+leverageRatio1)
        let leverageRatio2 =  (b.strikePrice / b.conversionRatio) / b.lastDone
        //console.log('杠杆比率2：'+leverageRatio2)
        return leverageRatio2 - leverageRatio1
    }).slice(0, 5)
    console.log('牛熊证筛选完毕：')
    console.log(JSON.stringify(arr2))
    for(let i = 0; i< arr2.length; i++) {
        let stock = arr2[i]
        // 查询卖一价格
        const deRsp = await ctx.depth(stock.symbol)
        stock.ask = deRsp.asks[0]
    }
    // 选中的牛熊证
    const selectNB = arr2.sort((a, b) => a.ask.price - b.ask.price)
    for (let obj of selectNB) {
      console.log(JSON.stringify(obj))
    }
    return new Promise((resolve) => {
        resolve(selectNB)
    });
}

// 购买股票牛熊证-限价单
async function tradeCBBC1(stock, price , num) {
    console.log('打印price , num:::' + price.price + "::::" + num)
    const tcx = await tradeContext;
    const resp = await tcx.submitOrder({
        symbol: stock.symbol,
        orderType: OrderType.LO,
        side: OrderSide.Buy,
        submittedQuantity: new Decimal(num), // 'string类型'
        timeInForce: TimeInForceType.Day,
        submittedPrice : price.price,
        remark: "极限档下单",
    });
    // 订单委托成功的id
    return resp.orderId
}

// 购买股票牛熊证-市价单
async function tradeCBBC2(stock, num) {
    const tcx = await tradeContext
    const resp = await tcx.submit_order({
        symbol: stock.symbol,
        orderType: OrderType.MO,
        side: OrderSide.Buy,
        submittedQuantity: new Decimal(num + ''), // 'string类型'
        timeInForce: TimeInForceType.Day,
    })
    // 订单委托成功的id
    return resp.orderId
}

exports.quoteContext = quoteContextReq
exports.tradeContext = tradeContextReqReq
exports.accountBalance = accountBalance
exports.searchCBBC = searchCBBC
exports.selectIntraday = selectIntraday
exports.quote = quote
exports.tradingSessionHK = tradingSessionHK

exports.tradeCBBC1 = tradeCBBC1
exports.tradeCBBC2 = tradeCBBC2