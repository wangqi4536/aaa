const fs = require('fs');
const path = require('path');
const cron = require('node-cron');
const longportAPI = require('./longportAPI')
const timeUtils = require('./utils/timeUtils')
const RSIUtil = require('./utils/RSI')

// 全局配置
const CONFIG = {
    switch:  false, // 本地验算与模拟交易开关,false为本地模拟

    symbol: "HSI.HK",
    tradingHours: {
        morning: { start: '09:50', end: '12:00' },
        afternoon: { start: '13:00', end: '15:45' }
    },
    rsiCalculationInterval: 10000, // 10秒
    maxPositionValue: 45000, // 最大持仓金额
    initialCapital: 120000, // 初始资金
    bankruptcyPrice: 0.010, // 爆仓价格
    cooldownPeriod: 6 * 60 * 1000 // 加仓以及减仓的冷却周期 6分钟
};

// 全局变量
let account = { sum: 0, money: 0, 'P&L': [], holdings: [] };
let hsiData = { currentPrice: 0, prevPrice: 0, changePercent: 0, high: 0, low: 0 }; //恒指数据， 单日，前一日，幅度，最高，最低
let rsiData = { details: [] };
let currentDate = new Date().toISOString().split('T')[0].replace(/-/g, '-').slice(2);
let todayDetails = {details: [], 'P&L': 0 };
let rsiValues = []; // 存储最近的RSI值用于计算
let CBBC = {
    symbol: '',
    type: 0,
}; // 今日待操作牛熊证
let task = { // 任务是否开始执行，执行时间
    init: false,
    initTime: 957,
    add: false,
    addTime: [958, 1445],
    reduce: false,
    reduceTime: [1000, 1505],
    reduceProfitRatio: [65, 110, 200, 300], // 对应的盈利比例减仓1/3
    clear: false,
    clearTime: 1520,
    close: false,
    closeTime: 1605
}

// 初始化
function init() {
    try {
        // 判断是否交易日
        //if (!isTradingDay()) return

        // 检查并执行初始化
        checkAndExecuteInit();
        
        // 启动加仓定时任务
        addPositionTask();
        
        // 启动减仓定时任务
        reducePositionTask();
        
        // 尾盘清仓任务
        //clearPositionTask();

        // 启动收盘任务
        //closeRecordTask();
    } catch (error) {
        console.error('程序运行失败:', error);
    }
}

// 校验时间是否大于等于预设值
function timeValid(validTime) {
    const timeStr = timeUtils.formatCurrentTime('HH:mm')
    const numericTime = timeStr.replace(":", ""); // "0930"
    const numericValue = parseInt(numericTime, 10); // 930（数字类型）
    return validTime <= numericValue
}

// 校验时间是否在时间区间内
function timeListValid(validTimeList) {
    const timeStr = timeUtils.formatCurrentTime('HH:mm')
    const numericTime = timeStr.replace(":", ""); // "0930"
    const numericValue = parseInt(numericTime, 10); // 930（数字类型）
    return  validTimeList[0] <= numericValue && numericValue <= validTimeList[1]
}
async function checkAndExecuteInit() {
    if (!timeValid(task.initTime) && !task.init && CBBC.symbol) return
    console.log("开始账号初始化操作")
    currentDate = new Date().toISOString().split('T')[0].replace(/-/g, '-').slice(2);
    // 初始化账号数据
    await loadAccountData();

    // 筛选今日交易股票代码
    initializeTodayDetails();
    task.init = true
    // 开启定时任务实时更新恒指数据，并计算RSI
    intervalId = setInterval(async () => {
        try {
            // 港股结束时，停止计算
            if (timeValid(1602)) clearInterval(intervalId);
            // 查询分时数据
            const HSIIntradays = await longportAPI.selectIntraday(CONFIG.symbol)
            // 更新恒指全局数据
            const HSIData = HSIIntradays[HSIIntradays.length - 1]
            updateHSIData({
                lastDone: HSIData.price,
                prevClose: hsiData.prevPrice,
                high: Math.max( hsiData.high, calculateChangePercent(HSIData.price, hsiData.prevClose)),
                low: Math.min(hsiData.low, calculateChangePercent(HSIData.price, hsiData.prevClose)),
            })
            // 提取分时价格
            const intradayPrices = HSIIntradays.map(item => item.price);
            // 先设置一分钟的精度，TODO，待补充数据（后期可以把数据量为半分钟，6的周期加一倍为12）
            rsiValues = RSIUtil.calculateRSI(intradayPrices, 6)
            console.log('最新的RSI值：', rsiValues[rsiValues.length - 1])
            
        } catch (error) {
            console.error('恒指分时数据及RSI计算失败:', error);
        }
    }, CONFIG.rsiCalculationInterval);
    console.log("账号初始化操作完成")
}

// 启动加仓定时任务
function addPositionTask() {
    if (!timeListValid(task.addTime) && !task.add && CBBC.symbol) return
    task.add = true
    // 开启定时任务实时更新恒指数据，并计算RSI
    intervalAddId = setInterval(async () => {
        try {
            // 加仓最后时间，结束循环
            if (timeValid(task.addTime[1])) {
                clearInterval(intervalAddId);
            }
            // 计算3分钟平均RSI
            const avgRSI = calculateAverageRSI(3); // 3分钟平均数值
            
            executeAddPositionStrategy(avgRSI);
        } catch (error) {
            console.error('执行加仓动作失败:', error);
        }
    }, CONFIG.rsiCalculationInterval);
}

// 启动减仓定时任务
function reducePositionTask() {
    if (!timeListValid(task.reduce) && !task.reduceTime && CBBC.symbol) return
    task.reduce = true
    // 开启定时任务实时更新恒指数据，并计算RSI
    intervalReduceId = setInterval(async () => {
        try {
            // 加仓最后时间，结束循环
            if (timeValid(task.reduceTime[1])) {
                clearInterval(intervalReduceId);
            }
            // 计算3分钟平均RSI
            const avgRSI = calculateAverageRSI(3); // 3分钟平均数值
            
            executeReducePositionStrategy(avgRSI)
        } catch (error) {
            console.error('执行减仓动作失败:', error);
        }
    }, CONFIG.rsiCalculationInterval);
}

// 尾盘清仓任务
function clearPositionTask() {
    if (!timeValid(task.clear) && !task.clearTime) return
    task.clear = true
    // 开启定时任务实时更新恒指数据，并计算RSI
    intervalClearId = setInterval(async () => {
        try {
            // 加仓最后时间，结束循环
            if (timeValid(task.clearTime)) {
                clearInterval(intervalClearId);
            }

            console.log('执行3:20清仓操作...');
            clearSell()
        } catch (error) {
            console.error('执行清仓动作失败:', error);
        }
    }, CONFIG.rsiCalculationInterval);
}

// 启动收盘任务
function closeRecordTask() {
    if (!timeValid(task.close) && !task.closeTime) return
    task.close = true
    // 开启定时任务实时更新恒指数据，并计算RSI
    intervalCloseId = setInterval(async () => {
        try {
            // 加仓最后时间，结束循环
            if (timeValid(task.closeTime)) {
                clearInterval(intervalCloseId);
            }
            console.log('启动收盘任务')
            executeCloseRecord();
        } catch (error) {
            console.error('执行减仓动作失败:', error);
        }
    }, CONFIG.rsiCalculationInterval);
}

// 加载账户数据
async function loadAccountData() {
    try {
        if (!CONFIG.switch) {
            // 读取本地文件
            const accountFilePath = path.join(__dirname, '../account/account.json');
            if (fs.existsSync(accountFilePath)) {
                const data = fs.readFileSync(accountFilePath, 'utf8');
                account = JSON.parse(data);
                console.log('账户数据加载成功');
                return new Promise((resolve) => {
                    resolve(true)
                })
            }
        } else {
            // 模拟/实盘
            const accountBalance = await longportAPI.accountBalance()
            const hsiAccount = accountBalance[0]
            const { net_assets, total_cash} = hsiAccount
            account = {
                sum: net_assets, money: total_cash, 'P&L': [], holdings: []
            }
            // 查询股票持仓TODO
        }
        
    } catch (error) {
        console.error('加载账户数据失败:', error);
        throw error;
    }
}


// 股票清仓
function clearOut() {
    // 查询一下股票当前持仓，开始清仓
    if (!CONFIG.switch) {
        // 本地交易
        if (account.holdings.length > 0) {
            account.holdings.forEach(async (item) => {
                // {"symbol": "59628", "price" : 0.010, "volume": 500000}
                const {symbol, price, volume} = item
                const Intradas = await longportAPI.selectIntraday(symbol)
                const sellPrice = Intradas.pop().price === CONFIG.bankruptcyPrice ? 0 : Intradas.pop().price - 0.001
                const time = timeUtils.formatCurrentTime()
                console.log(`卖出股票 ${symbol}，价格: ${sellPrice}，数量: ${volume}`);
                // 计算总市值
                account.sum = sellPrice === 0 ? (account.sum - 0.010*volume) : (account.sum + (sellPrice - price)*volume)
                // 计算可用现金
                account.money = account.money + (sellPrice === 0 ? 0: sellPrice * volume)
                // 计算今日盈亏数据
                const nowPL = account['P&L'].pop()
                if (nowPL.date == time) {
                    account['P&L'].push({
                        date: time, amount: nowPL.amount + (sellPrice - price)*volume
                    })
                } else {
                    account['P&L'].push({
                        date: time, amount: (sellPrice - price)*volume
                    })
                    account['P&L'].push(nowPL)
                }
                // 记录清仓股票操作
                recordTransaction('SELL', symbol, sellPrice, volume);
            })
            // 清空持股数据
            account.holdings = []
            
            saveAccountData();
            console.log('10点前清仓完成');
        }
    } else {
        // 模拟交易

    }
    
}
//筛选对应的今日交易股票代码
async function initializeTodayDetails() {
    // 查询恒指实时数据
    const quoteDatas = await longportAPI.quote([CONFIG.symbol])
    // 查询分时数据
    //const HSIIntradays = await longportAPI.selectIntraday(CONFIG.symbol)
    // 更新恒指全局数据
    updateHSIData(quoteDatas[0])
    // 清仓上一日持仓
    //clearOut()

    const type = hsiData.changePercent  > 0.67 ? 4 :  (hsiData.changePercent < -0.67 ? 3 : 0)
    // 不满足条件则返回false，等待时间合适在运行
    if (type === 0 || hsiData.changePercent > 5 || hsiData.changePercent < -5) return false
    
    // 查询牛熊证
    const CBBCs = await longportAPI.searchCBBC(type)

    // 计算合适的期权价格
    const price = calculatePrice(hsiData.changePercent)

    const validCBBS = CBBCs.filter(item => item.price >= price)
    if (validCBBS.length === 0)  return false
    // 取出符合条件交易量最高的股票代码
    console.log('打印需要交易的牛熊证：', JSON.stringify(validCBBS[0]))
    CBBC = validCBBS[0]
    CBBC['type'] = type // 4熊，3牛
    todayDetails = {
        details: [],
        'P&L': 0
    };
}

// 更新恒指全局数据
function updateHSIData(data) {
    hsiData.currentPrice = data.lastDone; // 当前价格
    hsiData.prevPrice = data.prevClose // 前一日收盘价
    hsiData.high = calculateChangePercent(data.high, data.prevClose); // 当日最高
    hsiData.low = calculateChangePercent(data.low, data.prevClose); // 当日最低
    hsiData.changePercent = calculateChangePercent(hsiData.currentPrice, data.prevClose);
    console.log(`恒生指数更新: 当前价格=${hsiData.currentPrice}, 涨跌幅=${hsiData.changePercent.toFixed(2)}%`);
}

// 计算价格
function calculatePrice(changePercent) {
    // 处理涨幅
    if (changePercent > 0) {
        if (changePercent > 1.8) return 0.040;
        if (changePercent > 1.3) return 0.036;
        if (changePercent > 0.7) return 0.031;
    } 
    // 处理跌幅
    else if (changePercent < 0) {
        // 注意：跌幅是负数，所以比较时需要取绝对值
        const absChange = Math.abs(changePercent);
        if (absChange > 1.8) return 0.040;
        if (absChange > 1.3) return 0.036;
        if (absChange > 0.7) return 0.031;
    }
    
    // 默认情况（变化不超过阈值或为0）
    return 0.030; // 您可以根据需要设置默认值
}



// 判断是否在交易时间内
function isInTradingHours() {
    const now = new Date();
    const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    
    // 检查是否为交易日（周一至周五）
    const day = now.getDay();
    if (day === 0 || day === 6) return false;
    
    // 检查是否在上午交易时间
    if (currentTime >= CONFIG.tradingHours.morning.start && currentTime <= CONFIG.tradingHours.morning.end) {
        return true;
    }
    
    // 检查是否在下午交易时间
    if (currentTime >= CONFIG.tradingHours.afternoon.start && currentTime <= CONFIG.tradingHours.afternoon.end) {
        return true;
    }
    
    return false;
}

// 判断是否为交易日
function isTradingDay() {
    const now = new Date();
    const day = now.getDay();
    return day >= 1 && day <= 5;
}

// 计算涨跌幅百分比
function calculateChangePercent(current, previous) {
    if (previous === 0) return 0;
    return ((current - previous) / previous) * 100;
}


// 保存RSI数据
function saveRSIData() {
    try {
        const filePath = path.join(__dirname, `RSI-${currentDate}.json`);
        fs.writeFileSync(filePath, JSON.stringify(rsiData, null, 2));
    } catch (error) {
        console.error('保存RSI数据失败:', error);
    }
}


// 计算N分钟平均RSI
function calculateAverageRSI(minutes) {
    if (rsiValues.length === 0) return 0;
    
    // 计算需要的样本数量（基于一分钟一次的采样频率，统计三分钟的）
    const recentValues = rsiValues.slice(-minutes);
    
    return recentValues.reduce((sum, value) => sum + value, 0) / recentValues.length;
}

// 执行加仓策略
async function executeAddPositionStrategy(currentRSI, avgRSI) {
    try {
        // 计算当前持仓总成本
        const currentPositionValue = calculateTotalCost(account.holdings)

        // 上一次加仓还在冷却期中，退出
        if (currentPositionValue > 0 && isInCooldow(account.holdings[account.holdings.length - 1].timestamp)) return
        
        // 检查剩余加仓金额是否可以继续加仓
        if (currentPositionValue >= CONFIG.maxPositionValue) {
            console.log(`当前持仓价值(${currentPositionValue})已达到最大限制(${CONFIG.maxPositionValue})，无法加仓`);
            return;
        }
        
        // 是否可加仓
        let addCondition = false
            
        if (CBBC.type === 4) {
            // 熊证加仓条件
            addCondition = (avgRSI >= 85) || 
                            (rsiValues.length >= 2 && 
                            rsiValues[rsiValues.length - 2] > 90 && 
                            currentRSI < rsiValues[rsiValues.length - 2] - 3);
        }
        if (CBBC.type === 3) {
            // 牛证加仓条件
            addCondition = (avgRSI <= 20) || 
                            (rsiValues.length >= 2 && 
                            rsiValues[rsiValues.length - 2] < 17 && 
                            currentRSI > rsiValues[rsiValues.length - 2] + 3);
        }
        
        // TODO计算恒生指数价格变动范围,后续加价格波动越大，持仓加越多
        //const priceChangeRange = Math.abs(hsiData.currentPrice - hsiData.prevPrice);
        if (addCondition) {
            // 计算可买入金额
            let availableAmount = Math.min(
                CONFIG.maxPositionValue - currentPositionValue,
                15000 // 单次最大买入金额
            );

            if (availableAmount == 0) {
                console.log("持仓金额达到上限，禁止加仓")
                return
            }
            
            // 查询牛熊证价格，高一价位买入
            const Intradas = await longportAPI.selectIntraday(symbol)
            const nowIntrada = Intradas.pop()
            const buyPrice = nowIntrada.price === CONFIG.bankruptcyPrice ? 0 : nowIntrada.price + 0.001
            const volume = Math.ceil((availableAmount/buyPrice) / 10000) * 10000
            // 执行买入
            await executeBuy(nowIntrada.symbol, buyPrice == 0.011 ? 0.010 : buyPrice, volume);
        }
        
    } catch (error) {
        console.error('执行加仓策略失败:', error);
    }
}

// 计算持仓成本
function calculateTotalCost(holdings) {
    if (holdings.length > 0) return 0
    return holdings.reduce(
        (total, holding) => total + (holding.price * holding.volume),
        0
    );
}


// 是否在加减仓的冷却期中
function isInCooldow(lastAddTime) {
    const now = Date.now();
    const elapsed = now - lastAddTime;
    return elapsed <= CONFIG.cooldownPeriod;
}
    

// 执行减仓策略
// 执行1/3减仓法，满足条件则减仓1/3，并且设置个延时任务20分钟后减仓1/3
// 成本减仓法： 盈利超过65%，110%，200% 300%时，分别减仓1/3(最低减仓80000股)
async function executeReducePositionStrategy(currentRSI, avgRSI) {
    try {
        if (account.holdings.length  === 0) return
        // 对多个相同股票的仓位进行合并，卖出的只减少仓位的数量，并不修改价格等
        mergeHoldingsInPlace()
        const holding = account.holdings[0]
        
        // 筛选卖出操作
        const sellDetails = todayDetails.details.filter(item => item.side=="SELL")

        // 上一次减仓还在冷却期中，退出
        if (sellDetails.length > 0 && isInCooldow(sellDetails[sellDetails.length - 1].timestamp)) return
        
        // 是否满足减仓条件
        let reduceCondition = false
        // 是否触发二次减仓逻辑
        let reduceAgain = false
        if (CBBC.type === 4) {
            // 熊证减仓条件
            reduceCondition = (avgRSI <= 20) || 
                        (rsiValues.length >= 2 && 
                        rsiValues[rsiValues.length - 2] < 17 && 
                        currentRSI > rsiValues[rsiValues.length - 2] + 3);
            if(reduceCondition) reduceAgain = true
            
        }
        if (CBBC.type === 3) {
            // 牛证减仓条件
            reduceCondition = (avgRSI >= 85) || 
                        (rsiValues.length >= 2 && 
                        rsiValues[rsiValues.length - 2] > 90 && 
                        currentRSI < rsiValues[rsiValues.length - 2] - 3);
            if(reduceCondition) reduceAgain = true
        }

        // 查询牛熊证价格，低一价位卖出
        console.log('打印牛熊证', CBBC.symbol)
        const Intradas = await longportAPI.selectIntraday(CBBC.symbol)
        const nowIntrada = Intradas.pop()
        const sellPrice = nowIntrada.price === CONFIG.bankruptcyPrice ? 0 : nowIntrada.price - 0.001

        // 计算盈利百分比
        const profitPercent = ((sellPrice - holding.price) / holding.price) * 100;
        
        // 确定当前盈利处于阈值区间[65, 110, 200, 300], 依次递增逐渐触发阈值
        reduceCondition = isThreshold(profitPercent);
        
        // 同时满足减仓条件，并且已经盈利10%以上，才触发减仓
        if (reduceCondition && profitPercent >= 10) {
            // 减仓1/3，最低80000股
            const volume = reduceNum()

            // 执行卖出
            executeSell(nowIntrada.symbol, sellPrice, volume);

            // 二次卖出，过20分钟执行
            if(reduceAgain) {
                setTimeout(() => {
                    console.log('开始20分钟减仓')
                    againSell()
                }, 20*60*1000);
            }
        }

    } catch (error) {
        console.error('执行减仓策略失败:', error);
    }
}


function isThreshold(profitPercent) {
    if (task.reduceProfitRatio.length === 0) return false
    // 检查当前盈利百分比是否达到或超过第1个阈值, 并清除当前阈值
    if (profitPercent >= task.reduceProfitRatio[0]) {
        task.reduceProfitRatio.shift()
        return true
    }
    return false
}
// 减仓数量计算(最低减仓80000股)
function reduceNum() {
    const volume = account.holdings[0].volume
    const needReduceNum = Math.ceil((account.holdings[0].volume / 3) / 10000) * 10000
    return volume <= 80000 ? volume : ( needReduceNum <= 80000 ? 80000 : needReduceNum)
}

// 二次卖出
async function againSell() {
    // 查询牛熊证价格，低一价位卖出
    const Intradas = await longportAPI.selectIntraday(symbol)
    const nowIntrada = Intradas.pop()
    const sellPrice = nowIntrada.price - 0.001
    const holdingPrice = account.holdings[0].price
    // 盈利的情况下卖出
    if (holdingPrice + 0.003 <sellPrice) {
        // 执行卖出
        executeSell(nowIntrada.symbol, sellPrice, reduceNum());
    }
}

// 清仓卖出
async function clearSell() {
    // 查询牛熊证价格，低一价位卖出
    const Intradas = await longportAPI.selectIntraday(symbol)
    const nowIntrada = Intradas.pop()
    const sellPrice = nowIntrada.price - 0.001
    if(nowIntrada.price == 0.010) return // 爆仓价格不执行
    // 执行卖出
    executeSell(nowIntrada.symbol, sellPrice, account.holdings[0].volume);
}
// 相同股票的仓位进行合并，成本重新计算
function mergeHoldingsInPlace() {
  if (!account.holdings || account.holdings.length <= 1) return;
  
  // 使用Map进行合并计算
  const mergedMap = new Map();
  
  // 遍历所有持仓记录，按symbol合并
  account.holdings.forEach(holding => {
    const { symbol, price, volume, timestamp } = holding;
    
    if (mergedMap.has(symbol)) {
      const existing = mergedMap.get(symbol);
      
      // 计算加权平均价格
      const totalValue = (existing.price * existing.volume) + (price * volume);
      const newVolume = existing.volume + volume;
      const newPrice = totalValue / newVolume;
      
      // 更新合并后的记录
      mergedMap.set(symbol, {
        symbol,
        price: parseFloat(newPrice.toFixed(3)), // 保留3位小数
        volume: newVolume,
        timestamp: Math.max(existing.timestamp, timestamp)
      });
    } else {
      // 添加新记录
      mergedMap.set(symbol, { ...holding });
    }
  });
  
  // 清空原数组并添加合并后的记录
  account.holdings.length = 0;
  account.holdings.push(...mergedMap.values());
}

// 检查盈利情况并执行相应减仓
async function checkProfitAndReduce() {
    try {
        for (const holding of account.holdings) {
            // 跳过爆仓价格的持仓
            if (holding.price === CONFIG.bankruptcyPrice) {
                continue;
            }
            
            // 获取当前价格（模拟）
            const currentPrice = holding.price * (1 + (Math.random() * 0.05 - 0.025)); // 模拟价格波动
            
            // 计算盈利百分比
            const profitPercent = ((currentPrice - holding.price) / holding.price) * 100;
            
            // 检查是否满足长时间高盈利减仓条件
            if (profitPercent > 60) {
                // 检查是否已经达到3分钟
                const now = new Date();
                const holdingTime = now - new Date(holding.purchaseTime || now);
                
                if (holdingTime >= 180000) { // 3分钟
                    let sellVolume;
                    
                    if (profitPercent > 400) {
                        sellVolume = holding.volume; // 全部卖出
                    } else if (profitPercent > 200) {
                        sellVolume = Math.floor(holding.volume / 2); // 卖出一半
                    } else {
                        sellVolume = Math.floor(holding.volume / 3); // 卖出三分之一
                    }
                    
                    const sellPrice = currentPrice - CONFIG.sellPriceAdjustment;
                    await executeSell(holding.symbol, sellPrice, sellVolume);
                }
            }
        }
    } catch (error) {
        console.error('检查盈利并减仓失败:', error);
    }
}

// 执行买入
async function executeBuy(symbol, price, volume) {
    try {
        const amount = price * volume;
        
        // 检查资金是否足够
        if (amount > account.money) {
            console.log(`买入失败：资金不足，需要 ${amount}，可用 ${account.money}`);
            return false;
        }
        
        // 更新账户
        account.money -= amount;
        
        // 增加持仓
        account.holdings.push({
            symbol,
            price,
            volume,
            timestamp: new Date().getTime()
        });
        
        // 更新总资产
        updateAccountSum();
        
        // 记录交易
        recordTransaction('BUY', symbol, price, volume);
        
        console.log(`买入成功：${symbol}，价格：${price}，数量：${volume}，金额：${amount}`);
        return true;
    } catch (error) {
        console.error('执行买入失败:', error);
        return false;
    }
}

// 执行卖出
async function executeSell(symbol, price, volume) {
    try {
        const amount = price * volume;
        
        // 检查是否有足够持仓
        const holdingIndex = account.holdings.findIndex(h => h.symbol === symbol);
        
        if (holdingIndex < 0) {
            console.log(`卖出失败：没有持仓 ${symbol}`);
            return false;
        }
        
        const holding = account.holdings[holdingIndex];
        
        // 检查持仓数量是否足够
        if (volume >= holding.volume) {
            console.log(`卖出失败：持仓不足，需要 ${volume}，实际 ${holding.volume}`);
            return false;
        }
        
        // 更新账户
        account.money += amount;
        
        if (volume === holding.volume) {
            // 全部卖出
            account.holdings.splice(holdingIndex, 1);
        } else {
            // 部分卖出
            account.holdings[holdingIndex].volume -= volume;
        }
        
        // 更新总资产
        updateAccountSum();
        
        // 记录交易
        recordTransaction('SELL', symbol, price, volume);
        
        console.log(`卖出成功：${symbol}，价格：${price}，数量：${volume}，金额：${amount}`);
        return true;
    } catch (error) {
        console.error('执行卖出失败:', error);
        return false;
    }
}

// 部分清仓
async function partialClearance(percentage) {
    try {
        for (const holding of [...account.holdings]) {
            // 跳过爆仓价格的持仓
            if (holding.price === CONFIG.bankruptcyPrice) {
                continue;
            }
            
            const volume = Math.floor(holding.volume * percentage);
            const currentPrice = Math.max(holding.price - CONFIG.sellPriceAdjustment, 0.001);
            
            await executeSell(holding.symbol, currentPrice, volume);
        }
    } catch (error) {
        console.error('部分清仓失败:', error);
    }
}

// 全部清仓
async function fullClearance() {
    try {
        for (const holding of [...account.holdings]) {
            // 跳过爆仓价格的持仓
            if (holding.price === CONFIG.bankruptcyPrice) {
                continue;
            }
            
            const currentPrice = Math.max(holding.price - CONFIG.sellPriceAdjustment, 0.001);
            await executeSell(holding.symbol, currentPrice, holding.volume);
        }
    } catch (error) {
        console.error('全部清仓失败:', error);
    }
}

// 记录交易
function recordTransaction(side, symbol, price, volume) {
    const turnover = price * volume;
    const timeStr = new Date().toISOString();
    
    todayDetails.details.push({
        symbol,
        side,
        price,
        timestamp: new Date().getTime(),
        timeStr,
        volume,
        turnover
    });
    
    // 保存交易详情
    saveTodayDetails();
}

// 更新账户总资产
function updateAccountSum() {
    const holdingsValue = account.holdings.reduce(
        (total, holding) => total + (holding.price * holding.volume),
        0
    );
    
    account.sum = account.money + holdingsValue;
}

// 计算当日盈亏
function calculateDailyProfitAndLoss() {
    // 计算当日交易盈亏
    const buyTransactions = todayDetails.details.filter(t => t.side === 'BUY');
    const sellTransactions = todayDetails.details.filter(t => t.side === 'SELL');
    
    const buyTotal = buyTransactions.reduce((total, t) => total + t.turnover, 0);
    const sellTotal = sellTransactions.reduce((total, t) => total + t.turnover, 0);
    
    todayDetails['P&L'] = sellTotal - buyTotal;
    
    // 更新账户盈亏记录
    const todayRecordIndex = account['P&L'].findIndex(r => r.date === currentDate);
    
    if (todayRecordIndex >= 0) {
        account['P&L'][todayRecordIndex].amount = todayDetails['P&L'];
    } else {
        account['P&L'].push({ date: currentDate, amount: todayDetails['P&L'] });
    }
}

// 保存账户数据
function saveAccountData() {
    try {
        const filePath = path.join(__dirname, 'account.json');
        fs.writeFileSync(filePath, JSON.stringify(account, null, 2));
    } catch (error) {
        console.error('保存账户数据失败:', error);
    }
}

// 保存今日交易详情
async function saveTodayDetails() {
    try {
        const filePath = path.join(__dirname, `detail-${currentDate}.json`);
        fs.writeFileSync(filePath, JSON.stringify(todayDetails, null, 2));
    } catch (error) {
        console.error('保存今日交易详情失败:', error);
    }
}

// 尾盘任务
async function executeCloseRecord() {

    const HSIIntraday = await selectIntraday("HSI")
    const CBBCIntraday = await selectIntraday(CBBC.symbol)

    // 创建当日的恒生指数分时文件
    createDailyFiles("HSI", HSIIntraday)
    // 创建当日的牛熊证分时文件
    createDailyFiles(CBBC.symbol, CBBCIntraday)
    // 计算当日盈亏
    calculateDailyProfitAndLoss()
    // 更新总市值
    updateAccountSum()
    // 保存账号数据
    saveAccountData()

    // 重置全局变量，留第二天继续使用
    account = { sum: 0, money: 0, 'P&L': [], holdings: [] };
    hsiData = { currentPrice: 0, prevPrice: 0, changePercent: 0, high: 0, low: 0 }; //恒指数据， 单日，前一日，幅度，最高，最低
    rsiData = { details: [] };
    currentDate = new Date().toISOString().split('T')[0].replace(/-/g, '-').slice(2);
    todayDetails = {details: [], 'P&L': 0 };
    rsiValues = []; // 存储最近的RSI值用于计算
    CBBC = {
        symbol: '',
        type: 0,
    }; // 今日待操作牛熊证
    task = { // 任务是否开始执行，执行时间
        init: false,
        initTime: 957,
        add: false,
        addTime: [958, 1445],
        reduce: false,
        reduceTime: [1000, 1505],
        reduceProfitRatio: [65, 110, 200, 300], // 对应的盈利比例减仓1/3
        clear: false,
        clearTime: 1520,
        close: false,
        closeTime: 1605
    }
    console.log('今日收盘')
}


// 每天早上9:45执行，下午4:10停止
let cronTask;

// 启动任务
const startTime = '25 20 * * *'; // 09:56
cron.schedule(startTime, () => {
    console.log('启动定时任务');
    cronTask = setInterval(() => {
        console.log('111111')
        init()
    }, 10000)
});

// 停止任务
const endTime = '50 19 * * *'; // 16:10
cron.schedule(endTime, () => {
  console.log('停止定时任务');
  clearInterval(cronTask);
});
init()