
cd /d E:\stock\LP
cnpm run limit2
pause