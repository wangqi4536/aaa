const express = require('express');
const cors = require('cors');
const { Config, TradeContext, QuoteContext, NaiveDate,  OrderType, OrderSide, TimeInForceType, Decimal } = require('longport');

const app = express();

app.use(cors());
app.use(express.json());
// 支持从 public 目录或根目录提供静态文件
const path = require('path');
app.use(express.static('public'));
app.use(express.static(__dirname));

// ========== 用户配置 ==========
// 从命令行参数获取用户和端口
const userArg = process.argv[2] || 'laojiu';
const PORT = parseInt(process.argv[3]) || 3000;

// 用户配置映射
const userConfig = {
  laojiu: {
    name: '老九',
    realConfig: null,
    paperConfig: null
  },
  junyue: {
    name: '君悦',
    realConfig: null,
    paperConfig: null
  }
};

let allSymbol = [
    {key: 'QQQ.US',name: '纳指100'}, {key: 'SPY.US',name: '标普500'},
    {key: 'GLD.US',name: '黄金ETF'}, 
    {key: 'TSLA.US',name: '特斯拉'}, {key: 'NVDA.US',name: '英伟达'}, {key: 'SPCX.US',name: 'Space'},
    {key: 'SLV.US',name: '白银EFT'},
    {key: 'MSFT.US',name: '微软'}, {key: 'GOOGL.US',name: '谷歌'},{key: 'AVGO.US',name: '博通'},
    {key: 'AAPL.US',name: '苹果'},{key: 'AMZN.US',name: '亚马逊'}, {key: 'META.US',name: 'Meta'}, 
    {key: 'AMD.US',name: 'AMD'},  {key: 'INTC.US',name: '英特尔'}, {key: 'PLTR.US',name: 'PLTR'},
    {key: 'MU.US',name: '美光'},
    {key: 'SNDK.US',name: '闪迪'},
    {key: 'TSM.US',name: '台积电'},{key: 'ASML.US',name: '阿斯麦'},
    {key: 'BABA.US',name: '阿里巴巴'},{key: 'PDD.US',name: '拼多多'}
    ];

// 打印启动信息
console.log(`\n========================================`);
console.log(`👤 当前用户: ${userConfig[userArg] ? userConfig[userArg].name : '老九'}`);
console.log(`📌 启动命令: ${userArg}`);
console.log(`🔌 监听端口: ${PORT}`);
console.log(`========================================\n`);

// ========== 环境配置 ==========
// 修改这里切换默认环境：'paper' = 模拟盘, 'real' = 正式盘
let currentEnvironment = 'paper'; // 默认使用模拟盘

// 正式盘配置
const realConfig = new Config({
  appKey: "a640c4404d79114fb23b3f76ffc04176",
  appSecret: "507e944129f096fb00a1db98916b2db21803c7d62a77fb57a00338217ac8b9af",
  enablePrintQuotePackages: false,
  accessToken: "m_eyJhbGciOiJSUzI1NiIsImtpZCI6ImQ5YWRiMGIxYTdlNzYxNzEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJsb25nYnJpZGdlIiwic3ViIjoiYWNjZXNzX3Rva2VuIiwiZXhwIjoxNzg4NDMzMjIwLCJpYXQiOjE3ODA2NTcyMjEsImFrIjoiYTY0MGM0NDA0ZDc5MTE0ZmIyM2IzZjc2ZmZjMDQxNzYiLCJhYWlkIjoyMDQ5Njg0NCwiYWMiOiJsYiIsIm1pZCI6MTU5NTMyOTksInNpZCI6ImZSYjlvSmFOZSthbkc4NHZ6blpWMUE9PSIsImJsIjozLCJ1bCI6MCwiaWsiOiJsYl8yMDQ5Njg0NCJ9.pMSChJOZX4TKFn4QAIWHfapEOVzweK6jqgd6ua86m_J6Ao5tCgEXRXrDwvb8KaEafrz66jcjKnLR08fETUY7vMkAjeGMcaYoFjTeZP7zenvFzN96Bkyyk31fFDSarAUSvazI73bv8tgRd9KUhHy_z9Zp8_B2wsf3stDFVMAg4PyuokYb9OQqpPK3mGr1zdjviyZqYRFdIgSpMIjZHfqWc3BZ8s9WTqAJy5ttVhjg7PE8A2fpBqiw4-kd3_9rjRkafT7QJeL3MKVWPxOZQ3RKFfUq8BEGPZ13eq2nir4NczTvL7kDT0pZbxOa82-grXxl1rULzN0vLXuZQZXK61VPE9_BzifXZtqCWyTnRP1L8-KR5p8GzxbExvGQV6fzUVIa5aZVjCST-tOYqz1WIaD5aWmnQ6G9-igR6umFUysJsj6ARseblLyq46HfU5R2xkAYGOq2ZH0Y6_RCT9m2imqOV-iVZrj80pUeXshkjbWUzVtAls-ZhxLW9ojfj-VdLvAyjPOHiwW2SCR0mIGv0FOF_6oLWXBCCKroxlhwfDSbWJ6RhLNb7twO4QHTbFET8osErphl-dnsLff7S9qtzzkDE4nIAo9IrohKfQxOqTh21I-tyPVD3vALH-T0VssoOV5sEFbLWI9sCAI4Rq3Xfi9v70vo97pYyBAOeMw7oa4iX6w"
});

// 模拟盘配置
const paperConfig = new Config({
  appKey: "a640c4404d79114fb23b3f76ffc04176",
  appSecret: "507e944129f096fb00a1db98916b2db21803c7d62a77fb57a00338217ac8b9af",
  enablePrintQuotePackages: false,
  accessToken: "m_eyJhbGciOiJSUzI1NiIsImtpZCI6ImQ5YWRiMGIxYTdlNzYxNzEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJsb25nYnJpZGdlIiwic3ViIjoiYWNjZXNzX3Rva2VuIiwiZXhwIjoxNzg4NDMzNjUyLCJpYXQiOjE3ODA2NTc2NTMsImFrIjoiYTY0MGM0NDA0ZDc5MTE0ZmIyM2IzZjc2ZmZjMDQxNzYiLCJhYWlkIjoyMDUzMjY5NiwiYWMiOiJsYl9wYXBlcnRyYWRpbmciLCJtaWQiOjE1OTUzMjk5LCJzaWQiOiJFTWp0aW12RkpPUW9iZzBvZ3laMXFnPT0iLCJibCI6MywidWwiOjAsImlrIjoibGJfcGFwZXJ0cmFkaW5nXzIwNTMyNjk2In0.oGTXzpPG7BOWrut7PtoGRi9nX2zb8GWltURehYtVQe0oZjNdawBDWlQlaBwRjFAWDHKiMo9ZPj9FXVItaqcyBn_eQfYLOgIChHF91dWgqe3mfdxj7A_CDMPrp7omCZCq8TXzPDrijO_0o-Kmz8ERaXQXoRnK_BPQ2b4x6o-3RIUta0mm2OO7HIc7aBoawMBETsN6QpdSX4ksJ72AviPQ_lzk87y-OmpAh2cilX10mthdhp0XbWI-aEvbTrEIXQB_ngTPdUzaYfIDx3DPrx80DedW-BNHCNZxcIGquBs3wXuVI3yHmIydAtkvr3yCqI3hqaqVu93q-vfr7vdFl_5I71mjjyxqzc_WmUdGn8TTGGkqoensbxo52kEteG7A0cIDpr09nT0h5oSy2viEFzfow-mDsJwp1DTJ9D9mi-HgamqINI8etJiQ9JtAYnSu5YXsg6mCJm8Gj3Os3dAGqioy-A8WbFQnZu4y4ZgHJO6u_naErxjwPTlsb-ofVKVwBtpuWqqY3lqdMrFVh-eoi7RxZqmpphcSwy-mfDkBpdkuw6YjwHRAJvAvuemWGp-1KOG4qo_GHCVtoruoW0JglE8SLqqDcHqeP9D4maXB7Bp-U0R8OA_d0WLkWKisUwmHVGgzagDeFH3DlkM2WA19yUyU7_aF3sqb5F1kmGxQa1Hsouk"
});

// 正式盘2配置
const realConfig2 = new Config({
  appKey: "5c5c00f07e7ebbe75775e786163a55ce",
  appSecret: "a93214d28e01fdf22534d379b46cd151c729421cd7e9ff8391df85980275c869",
  enablePrintQuotePackages: false,
  accessToken: "m_eyJhbGciOiJSUzI1NiIsImtpZCI6ImQ5YWRiMGIxYTdlNzYxNzEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJsb25nYnJpZGdlIiwic3ViIjoiYWNjZXNzX3Rva2VuIiwiZXhwIjoxNzg4NzEyMjIzLCJpYXQiOjE3ODA5MzYyMjMsImFrIjoiNWM1YzAwZjA3ZTdlYmJlNzU3NzVlNzg2MTYzYTU1Y2UiLCJhYWlkIjoyMDU0NDcwOSwiYWMiOiJsYiIsIm1pZCI6MTYzMzE0MzMsInNpZCI6ImF5THY0M0Z6SWNONmU4Nys0OXV1MFE9PSIsImJsIjozLCJ1bCI6MCwiaWsiOiJsYl8yMDU0NDcwOSJ9.2sBH0NpCIRDjRtn6m5qNRVUGMKc0CDbKtgS07mPi5RTKzVhyXTxWwQEtnaris7DSx3D5VILwjjXQOt1SEaCNm4fT1SqtmZawKaICpettjeZvTEfhZKWn0UmBudV6JnJz6BpuOnfny5VWRtmN2BWAvNmC7DHi6n4sPs4k7d-O2_9CQvnahSRJbWCFqmOTmSwBsps_z7JWhefKdNZtc9TXeDX2KWCSKYb1IzNDXF611blVyDZ9nz1j96u8uOAPUU-vWB0-5npfetMJge0KhHd2pvw3-4tsSLL6grSZ5GcUWlS9dc5ogyq1nAiT6MTia88SY6RZCimxSZRzzpvEVFC8Sri51O8dJXciRuL5WPF9L90mytF-VtwLExE_PZnyOWgX83xo8saInlWmZ4iI6-eC5ZX4Bgb3PJ5VkuagTSi2lnIX9yBlevtZGWxOmW8DA_SdDJ8yPbLrDannYa920alMajhEv4OgFwEV48TQFr5OCtyswy39UFv6N_ljzsGIy-idkxbKzVVHdJtV42tg5W19TNwD9QjaX2Eh1o9jY3k3NQMtXx8dCbzFIXaD8fpfzHUgPJA8wZdXC1dslX3LXlbnA-aoZW_K0uIvueLS51-vdIDZyU4J-WInHaEY2ovhcRnIMZL3DnlD7r2s5wwJFN7yW3q-6L8jpEkUjlCXDd-g5Rc"
});

// 模拟盘2配置
const paperConfig2 = new Config({
  appKey: "5c5c00f07e7ebbe75775e786163a55ce",
  appSecret: "a93214d28e01fdf22534d379b46cd151c729421cd7e9ff8391df85980275c869",
  enablePrintQuotePackages: false,
  accessToken: "m_eyJhbGciOiJSUzI1NiIsImtpZCI6ImQ5YWRiMGIxYTdlNzYxNzEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJsb25nYnJpZGdlIiwic3ViIjoiYWNjZXNzX3Rva2VuIiwiZXhwIjoxNzgyNDY5Mjg4LCJpYXQiOjE3NzQ2OTMyODgsImFrIjoiNWM1YzAwZjA3ZTdlYmJlNzU3NzVlNzg2MTYzYTU1Y2UiLCJhYWlkIjoyMDc0OTc4MCwiYWMiOiJsYl9wYXBlcnRyYWRpbmciLCJtaWQiOjE2MzMxNDMzLCJzaWQiOiI0R0d6aVF6ZzNzV2xXT0xWRkNXb2tBPT0iLCJibCI6MywidWwiOjAsImlrIjoibGJfcGFwZXJ0cmFkaW5nXzIwNzQ5NzgwIn0.fiTKuImms3RBrCgUyru3d9Vl-VwgS2E4w4mRxKpjlN4KTugH_zyjH8vVeN9TJW3h8_HI_QGtRYkb7KFu9FkIZigjQl_2eLQ0QLcYHKZwdmeWk43WEFPe-_LtoUesX5jwJT8OQB8X9e_3_lrPzMwI5RPOv-7aPkObjpu1Bx25ouL-kDMT0jNrYKb55W8keIZLeJl_EJeyE0KPJhTn1CYcIQD5DXvSGykGomvJFBPr_kp0Gmydge6gop1zD20PcbJUNV4e96d8DUyubT8KGSSoRtoG--Wo4BPQTzcRvyhEvud_wP5AcfnU6nEBJBqECNkd_MLIWKs1L0CkgY5OI06EYmeC7Aee_jH_McNVs251yiIR_aIztI60tsKqOvi0WIbDzXgWYuizR0v1XTrHUWZ0joJtIt3Z8oKDmxMiJZnboJHyMTetBjXiTFfpQgx0uzCiBijg-g6JsqSE2r8_KZGiOwYMYJRLRAq9atgCQ24pvTELD1Uz9f2oC0lMCR0JlEgmWXqFuwoPpitSoB-KmGxAC5ymHXhpDsTvhzO3SoFWiPDDIFhBeGdMfq7yqpb0xV1zN0M7kSI2ZUoPxn4gqcSz3QUfx1bRfnXqWiyX37kgWrUAeFRHJ4vSoHUImNEg4YLMaZ1Udml9p5An1WIOTDxUVQV_O46vwrznmBbRRyhuz-k"
});

// 更新用户配置映射
userConfig.laojiu.realConfig = realConfig;
userConfig.laojiu.paperConfig = paperConfig;
userConfig.junyue.realConfig = realConfig2;
userConfig.junyue.paperConfig = paperConfig2;

// 当前选中的用户（可以通过 API 切换）
let currentUserKey = userArg; // 默认从命令行参数获取

// 获取当前用户
function getActiveUser() {
  return userConfig[currentUserKey] || userConfig.laojiu;
}

// 获取当前配置
function getCurrentConfig() {
  const user = getActiveUser();
  return currentEnvironment === 'paper' ? user.paperConfig : user.realConfig;
}

// 全局单例实例（每个用户独立）
let quoteCtx = null;
let tradeCtx = null;

async function getQuoteContext() {
  if (!quoteCtx) {
    quoteCtx = await QuoteContext.new(getCurrentConfig());
    console.log(`✅ QuoteContext 实例已创建 (${getActiveUser().name} - ${currentEnvironment === 'paper' ? '模拟盘' : '正式盘'})`);
  }
  return quoteCtx;
}

async function getTradeContext() {
  if (!tradeCtx) {
    tradeCtx = await TradeContext.new(getCurrentConfig());
    console.log(`✅ TradeContext 实例已创建 (${getActiveUser().name} - ${currentEnvironment === 'paper' ? '模拟盘' : '正式盘'})`);
  }
  return tradeCtx;
}

// 切换用户并重置连接
function switchUser(userKey) {
  if (userConfig[userKey]) {
    currentUserKey = userKey;
    quoteCtx = null; // 重置连接
    tradeCtx = null; // 重置连接
    console.log(`🔄 已切换至用户: ${getActiveUser().name}`);
    return true;
  }
  return false;
}

// 切换环境并重置连接
function switchEnvironment(env) {
  if (env === 'paper' || env === 'real') {
    currentEnvironment = env;
    quoteCtx = null; // 重置连接
    tradeCtx = null; // 重置连接
    console.log(`🔄 ${getActiveUser().name} - 环境已切换至: ${env === 'paper' ? '模拟盘' : '正式盘'}`);
    return true;
  }
  return false;
}

// API: 获取当前用户信息
app.get('/api/user', (req, res) => {
  res.json({
    success: true,
    data: {
      username: getActiveUser().name,
      userKey: currentUserKey,
      environment: currentEnvironment === 'paper' ? '模拟盘' : '正式盘'
    }
  });
});

// API: 获取所有可用用户列表
app.get('/api/users', (req, res) => {
  const users = Object.entries(userConfig).map(([key, user]) => ({
    userKey: key,
    username: user.name,
    isActive: key === currentUserKey
  }));
  res.json({ success: true, data: users });
});

// API: 切换用户
app.post('/api/user/switch', (req, res) => {
  const { userKey } = req.body;
  if (switchUser(userKey)) {
    res.json({
      success: true,
      data: {
        username: getActiveUser().name,
        userKey: currentUserKey,
        environment: currentEnvironment === 'paper' ? '模拟盘' : '正式盘'
      }
    });
  } else {
    res.json({
      success: false,
      error: '无效的用户，请使用 "laojiu" 或 "junyue"'
    });
  }
});

// API: 获取当前环境
app.get('/api/environment', (req, res) => {
  res.json({
    success: true,
    data: {
      environment: currentEnvironment,
      display: currentEnvironment === 'paper' ? '模拟盘' : '正式盘'
    }
  });
});

// API: 切换环境
app.post('/api/environment', (req, res) => {
  const { environment } = req.body;
  if (switchEnvironment(environment)) {
    res.json({
      success: true,
      data: {
        environment: currentEnvironment,
        display: currentEnvironment === 'paper' ? '模拟盘' : '正式盘'
      }
    });
  } else {
    res.json({
      success: false,
      error: '无效的环境参数，请使用 "paper" 或 "real"'
    });
  }
});

// API: 获取自动交易配置
app.get('/api/auto-trading/config', (req, res) => {
  res.json({ success: true, data: autoTradingConfig });
});

// API: 更新自动交易配置
app.post('/api/auto-trading/config', (req, res) => {
  const { enabled, mode, buyTime, buyDate, buyTomorrow, optionType, buyQuantity, maxOptionPrice, stopLossTime, stopLossPrice, sellTime } = req.body;
  
  if (typeof enabled === 'boolean') {
    autoTradingConfig.enabled = enabled;
  }
  if (mode && ['all', 'buy', 'stopLoss', 'sell'].includes(mode)) {
    autoTradingConfig.mode = mode;
  }
  if (buyTime) {
    autoTradingConfig.buyTime = buyTime;
  }
  if (buyDate) {
    autoTradingConfig.buyDate = buyDate;
  }
  if (typeof buyTomorrow === 'boolean') {
    autoTradingConfig.buyTomorrow = buyTomorrow;
  }
  if (optionType) {
    autoTradingConfig.optionType = optionType;
  }
  if (typeof buyQuantity === 'number' && buyQuantity > 0) {
    autoTradingConfig.buyQuantity = buyQuantity;
  }
  if (typeof maxOptionPrice === 'number' && maxOptionPrice > 0) {
    autoTradingConfig.maxOptionPrice = maxOptionPrice;
  }
  if (typeof stopLossTime === 'string' && stopLossTime) {
    autoTradingConfig.stopLossTime = stopLossTime;
  }
  if (typeof stopLossPrice === 'number' && stopLossPrice > 0) {
    autoTradingConfig.stopLossPrice = stopLossPrice;
  }
  if (typeof sellTime === 'string' && sellTime) {
    autoTradingConfig.sellTime = sellTime;
  }
  
  const optionTypeMap = { 'QQQ_C': 'QQQ看涨', 'QQQ_P': 'QQQ看跌', 'SPY_C': 'SPY看涨', 'SPY_P': 'SPY看跌', 'GC_C': '黄金看涨', 'GC_P': '黄金看跌' };
  const modeMap = { 'all': '自动交易(完整流程)', 'buy': '只买入', 'stopLoss': '只止损', 'sell': '只卖出' };
  
  console.log(`\n🔄 自动交易配置已更新:`);
  console.log(`  开关: ${autoTradingConfig.enabled ? '🟢 开启' : '🔴 关闭'}`);
  console.log(`  模式: ${modeMap[autoTradingConfig.mode] || autoTradingConfig.mode}`);
  console.log(`  买入时间: ${autoTradingConfig.buyDate} ${autoTradingConfig.buyTime}`);
  console.log(`  次日期权: ${autoTradingConfig.buyTomorrow ? '是（买明天）' : '否（买今天）'}`);
  console.log(`  期权类型: ${optionTypeMap[autoTradingConfig.optionType] || autoTradingConfig.optionType}`);
  console.log(`  买入张数: ${autoTradingConfig.buyQuantity}`);
  console.log(`  最高期权价格: $${autoTradingConfig.maxOptionPrice}`);
  console.log(`  止损时间: ${autoTradingConfig.stopLossTime}`);
  console.log(`  止损价格: $${autoTradingConfig.stopLossPrice}`);
  console.log(`  卖出时间: ${autoTradingConfig.sellTime}`);
  
  res.json({ success: true, data: autoTradingConfig });
});

// API: 获取自动交易状态（兼容旧接口）
app.get('/api/auto-trading/status', (req, res) => {
  res.json({ success: true, data: autoTradingConfig.enabled });
});

// API: 切换自动交易状态（兼容旧接口）
app.post('/api/auto-trading/toggle', (req, res) => {
  autoTradingConfig.enabled = !autoTradingConfig.enabled;
  console.log(`\n🔄 自动交易开关 ${autoTradingConfig.enabled ? '🟢 已开启' : '🔴 已关闭'}`);
  res.json({ success: true, data: autoTradingConfig.enabled });
});

app.get('/api/qqq-quote', async (req, res) => {
  try {
    const ctx = await getQuoteContext();
    const resp = await ctx.quote(['QQQ.US']);
    //console.log('📊 QQQ 实时行情:', JSON.stringify(resp, null, 2));
    res.json({ success: true, data: resp });
  } catch (error) {
    console.error('❌ QQQ 行情查询失败:', error.message);
    res.json({ success: false, error: error.message });
  }
});

app.get('/api/option-chain', async (req, res) => {
  try {
    const ctx = await getQuoteContext();
    
    // 获取标的参数，默认QQQ.US
    const underlyingSymbol = req.query.symbol || 'QQQ.US';
    
    // 获取标的实时价格
    const quoteResult = await ctx.quote([underlyingSymbol]);
    const underlyingPriceFloat = parseFloat(quoteResult[0].lastDone);
    const underlyingPrice = Math.round(underlyingPriceFloat);
    
    // 获取查询日期，默认今天
    let queryDate = new Date();
    if (req.query.date) {
      queryDate = new Date(req.query.date);
    }
    
    // 构建请求参数
    const requestParams = {
      symbol: underlyingSymbol,
      expiry: new NaiveDate(queryDate.getFullYear(), queryDate.getMonth() + 1, queryDate.getDate())
    };
    
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('📡 optionChainInfoByDate 请求参数:');
    console.log(JSON.stringify(requestParams, null, 2));
    console.log('查询日期:', queryDate.toISOString().split('T')[0]);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    
    const optionChain = await ctx.optionChainInfoByDate(underlyingSymbol, new NaiveDate(queryDate.getFullYear(), queryDate.getMonth() + 1, queryDate.getDate()));
    
    // 打印原始数据结构 - 详细打印
    console.log('📥 原始期权链数据 (共', optionChain.length, '条):');
    for (let i = 0; i < Math.min(optionChain.length, 3); i++) {
      const obj = optionChain[i];
      console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
      console.log('对象', i, ':', obj);
      console.log('对象属性:', Object.keys(obj));
      if (obj.toJSON) {
        console.log('toJSON结果:', obj.toJSON());
      }
      console.log('toString结果:', obj.toString());
    }
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    
    // 筛选符合行权价范围的期权（price是字符串类型）
    // 行权价偏差范围：0-50（Call: 标的价格 ~ 标的价格+50，Put: 标的价格-50 ~ 标的价格）
    const filteredChain = optionChain.filter(opt => {
      const strike = parseInt(opt.price); // price是字符串，需要转换为数字
      const isCallInRange = strike >= underlyingPrice && strike <= underlyingPrice + 50;
      const isPutInRange = strike >= underlyingPrice - 50 && strike <= underlyingPrice;
      return isCallInRange || isPutInRange;
    });
    
    // 收集需要查询的期权代码
    const allSymbols = [];
    filteredChain.forEach(opt => {
      if (opt.callSymbol) allSymbols.push(opt.callSymbol);
      if (opt.putSymbol) allSymbols.push(opt.putSymbol);
    });
    
    console.log('📈 筛选后的期权信息:');
    console.log('  标的:', underlyingSymbol);
    console.log('  标的价格:', '$' + underlyingPriceFloat, '→', '取整: $' + underlyingPrice);
    console.log('  Call范围:', '$' + underlyingPrice, '~', '$' + (underlyingPrice + 50));
    console.log('  Put范围:', '$' + (underlyingPrice - 50), '~', '$' + underlyingPrice);
    console.log('  符合条件的期权代码数量:', allSymbols.length);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    
    if (allSymbols.length > 0) {
      // 获取期权实时报价
      const optionQuotes = await ctx.optionQuote(allSymbols);
      
      // 分类整理 Call 和 Put（过滤价格>5的期权）
      const calls = [];
      const puts = [];
      
      // 构建期权数据（包含行权价）
      // symbol格式: QQQ260608C930000.US 或 QQQ260608P505000.US
      optionQuotes.forEach(quote => {
        // 提取行权价：930000 → 930
        const strikeMatch = quote.symbol.match(/[CP](\d{6})\.US$/);
        let strike = 0;
        if (strikeMatch) {
          strike = parseInt(strikeMatch[1]) / 1000; // 930000 → 930
        }
        
        // 获取期权价格
        const optionPrice = parseFloat(quote.lastDone);
        
        // 过滤期权最新价不在 0.17-4.3 范围内的期权
        if (optionPrice < 0.17 || optionPrice >= 4.3) {
          console.log(`⏭️ 过滤期权: ${quote.symbol}, 价格: $${optionPrice}`);
          return;
        }
        
        const optData = {
          symbol: quote.symbol,
          lastDone: quote.lastDone,
          strike: strike
        };
        
        if (quote.symbol.includes('C')) {
          calls.push(optData);
        } else {
          puts.push(optData);
        }
      });
      
      // 按行权价排序
      calls.sort((a, b) => a.strike - b.strike);
      puts.sort((a, b) => a.strike - b.strike);
      
      console.log('📊 整理后的期权数据:');
      console.log('  Call期权数量:', calls.length);
      console.log('  Put期权数量:', puts.length);
      console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
      
      res.json({ 
        success: true, 
        data: { 
          underlyingSymbol,
          underlyingPrice: underlyingPriceFloat, 
          underlyingPriceRounded: underlyingPrice, 
          queryDate: queryDate.toISOString().split('T')[0],
          calls, 
          puts 
        } 
      });
    } else {
      console.log('📈 期权链查询 - 标的: ' + underlyingSymbol + ', 价格: $' + underlyingPrice + ', 无符合条件的期权');
      res.json({ 
        success: true, 
        data: { 
          underlyingSymbol,
          underlyingPrice: underlyingPriceFloat, 
          underlyingPriceRounded: underlyingPrice, 
          queryDate: queryDate.toISOString().split('T')[0],
          calls: [], 
          puts: [] 
        } 
      });
    }
  } catch (error) {
    console.error('❌ 期权链查询失败:', error.message);
    res.json({ success: false, error: error.message });
  }
});

app.get('/api/available-dates', async (req, res) => {
  try {
    const dates = [];
    const today = new Date();
    
    // 生成从今天起往后35天的日期
    for (let i = 0; i < 35; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      dates.push({
        date: date.toISOString().split('T')[0],
        display: `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`,
        dayOfWeek: ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][date.getDay()]
      });
    }
    
    res.json({ success: true, data: dates });
  } catch (error) {
    res.json({ success: false, error: error.message });
  }
});

app.get('/api/account', async (req, res) => {
  try {
    const trade = await getTradeContext();
    const balances = await trade.accountBalance();
    
    console.log('📡 accountBalance() 返回数据:', JSON.stringify(balances, null, 2));
    
    if (balances && balances.length > 0) {
      const balance = balances[0];
      res.json({ 
        success: true, 
        data: {
          totalAssets: balance.netAssets ? Number(balance.netAssets) : 0,
          cash: balance.totalCash ? Number(balance.totalCash) : 0,
          currency: balance.currency || 'HKD'
        }
      });
    } else {
      res.json({ success: false, error: '未获取到账户信息' });
    }
  } catch (error) {
    res.json({ success: false, error: error.message });
  }
});

app.get('/api/positions', async (req, res) => {
  try {
    const trade = await getTradeContext();
    const quote = await getQuoteContext();
    const positions = await trade.stockPositions();
    
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('📡 stockPositions() 原始返回数据:');
    console.log('数据类型:', typeof positions);
    console.log('是否数组:', Array.isArray(positions));
    console.log('数据内容:', JSON.stringify(positions, null, 2));
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    
    // 正确处理嵌套数据结构: channels[].positions
    let allPositions = [];
    
    if (positions && positions.channels && Array.isArray(positions.channels)) {
      // 遍历所有渠道
      positions.channels.forEach(channel => {
        if (channel.positions && Array.isArray(channel.positions)) {
          allPositions = allPositions.concat(channel.positions);
        }
      });
    } else if (Array.isArray(positions)) {
      // 备用：如果直接返回数组
      allPositions = positions;
    } else if (positions && positions.stockPositions) {
      // 备用：如果在 stockPositions 字段中
      allPositions = positions.stockPositions;
    }
    
    console.log('📊 提取后的持仓数据:', JSON.stringify(allPositions, null, 2));
    res.json({ success: true, data: allPositions });
    // // 筛选 QQQ 期权持仓（symbol包含QQQ且包含.US）
    // const optionPositions = allPositions.filter(pos => 
    //   pos.symbol && pos.symbol.includes('QQQ')
    // );
    
    // console.log('🔍 筛选后的 QQQ 期权持仓:', JSON.stringify(optionPositions, null, 2));
    
    // if (optionPositions.length > 0) {
    //   const symbols = optionPositions.map(pos => pos.symbol);
    //   const optionQuotes = await quote.optionQuote(symbols);
      
    //   const enrichedPositions = optionPositions.map(pos => {
    //     const q = optionQuotes.find(o => o.symbol === pos.symbol);
    //     return { ...pos, quote: q };
    //   });
      
    //   console.log(`💼 持仓查询成功 - 找到 ${optionPositions.length} 个 QQQ 期权持仓`);
    //   console.log('持仓详情:', JSON.stringify(enrichedPositions, null, 2));
    //   res.json({ success: true, data: enrichedPositions });
    // } else {
    //   console.log('💼 持仓查询 - 暂无 QQQ 期权持仓');
    //   res.json({ success: true, data: [] });
    // }
  } catch (error) {
    console.error('❌ 持仓查询失败:', error.message);
    res.json({ success: false, error: error.message });
  }
});

// 订单详情查询 API
app.get('/api/order-detail', async (req, res) => {
  try {
    const { orderId } = req.query;
    
    if (!orderId) {
      res.json({ success: false, error: '请提供订单ID' });
      return;
    }
    
    const trade = await getTradeContext();
    
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('📡 查询订单详情 - 订单ID:', orderId);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    
    const orderDetail = await trade.orderDetail(orderId);
    
    console.log('📥 订单详情响应:');
    console.log('订单ID:', orderDetail.orderId);
    console.log('标的:', orderDetail.symbol);
    console.log('股票名称:', orderDetail.stockName);
    console.log('方向:', orderDetail.side === 1 ? '买入' : '卖出');
    console.log('订单类型:', orderDetail.orderType);
    console.log('订单状态:', orderDetail.status);
    console.log('提交数量:', orderDetail.quantity.toString());
    console.log('已执行数量:', orderDetail.executedQuantity.toString());
    console.log('提交价格:', orderDetail.price ? orderDetail.price.toString() : '无');
    console.log('成交价格:', orderDetail.executedPrice ? orderDetail.executedPrice.toString() : '无');
    console.log('提交时间:', orderDetail.submittedAt);
    console.log('最后更新:', orderDetail.updatedAt);
    console.log('拒绝原因:', orderDetail.msg);
    console.log('订单有效期:', orderDetail.timeInForce);
    console.log('到期日期:', orderDetail.expireDate);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('完整JSON数据:');
    console.log(JSON.stringify(orderDetail, (key, value) => {
      // 处理 Decimal 类型
      if (value && typeof value === 'object' && value.constructor.name === 'Decimal') {
        return value.toString();
      }
      return value;
    }, 2));
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    
    // 转换为可序列化的对象
    const orderData = {
      orderId: orderDetail.orderId,
      symbol: orderDetail.symbol,
      stockName: orderDetail.stockName,
      side: orderDetail.side === 1 ? '买入' : '卖出',
      sideCode: orderDetail.side,
      orderType: orderDetail.orderType,
      status: orderDetail.status,
      quantity: orderDetail.quantity.toString(),
      executedQuantity: orderDetail.executedQuantity.toString(),
      price: orderDetail.price ? orderDetail.price.toString() : null,
      executedPrice: orderDetail.executedPrice ? orderDetail.executedPrice.toString() : null,
      submittedAt: orderDetail.submittedAt,
      updatedAt: orderDetail.updatedAt,
      msg: orderDetail.msg,
      timeInForce: orderDetail.timeInForce,
      expireDate: orderDetail.expireDate
    };
    
    console.log('✅ 订单详情查询成功:', orderData.orderId);
    res.json({ success: true, data: orderData });
  } catch (error) {
    console.error('❌ 订单详情查询失败:', error.message);
    res.json({ success: false, error: error.message });
  }
});

app.post('/api/trade', async (req, res) => {
  try {
    const { symbol, side, quantity, orderType, price, outsideRth } = req.body;
    const trade = await getTradeContext();
    
    // 订单类型映射：字符串转数字枚举
    const orderTypeMap = {
      'MO': 3,  // 市价单 (Market Order)
      'LO': 1,  // 限价单 (Limit Order)
      'SC': 2,  // 止损单 (Stop Order)
      'SL': 4,  // 止损限价单 (Stop Limit Order)
    };
    
    // 订单方向映射：字符串转数字枚举
    const sideMap = {
      'Buy': 1,   // 买入
      'Sell': 2,  // 卖出
    };
    
    // 订单有效期映射：字符串转数字枚举
    const timeInForceMap = {
      'Day': 1,   // 当日有效
      'GTC': 2,   // 取消前有效 (Good Till Canceled)
      'IOC': 3,   // 立即执行或取消 (Immediate Or Cancel)
      'FOK': 4,   // 全部执行或取消 (Fill Or Kill)
    };
    
    // 盘前盘后映射：字符串转数字枚举
    const outsideRthMap = {
      'Unknown': 0,    // 未知
      'RTHOnly': 1,    // 仅常规交易时间 (默认)
      'AnyTime': 2,    // 任何时间
      'Overnight': 3,  // 隔夜
    };
    
    const orderTypeValue = orderTypeMap[orderType] !== undefined ? orderTypeMap[orderType] : 0;
    const sideValue = sideMap[side] !== undefined ? sideMap[side] : 1;
    const timeInForceValue = timeInForceMap['Day']; // 默认当日有效
    const outsideRthValue = outsideRthMap[outsideRth] !== undefined ? outsideRthMap[outsideRth] : 1; // 默认仅常规交易时间
    const quantityNum = parseInt(quantity);
    
    const outsideRthDisplay = {
      0: 'Unknown',
      1: 'RTHOnly',
      2: 'AnyTime',
      3: 'Overnight'
    }[outsideRthValue];
    
    console.log(`📝 提交订单 - 标的: ${symbol}, 方向: ${side} (${sideValue}), 数量: ${quantityNum}, 类型: ${orderType} (${orderTypeValue}), 有效期: Day (${timeInForceValue}), 盘前盘后: ${outsideRthDisplay} (${outsideRthValue})${orderType === 'LO' ? `, 限价: $${price}` : ''}`);
    
    // 构建订单参数
    const orderParams = {
      symbol,
      orderType: orderTypeValue,
      side: sideValue,
      quantity: new Decimal(quantityNum.toString()),
      submittedQuantity: new Decimal(quantityNum.toString()),
      timeInForce: timeInForceValue,
      outsideRth: outsideRthValue,
    };
    
    // 限价单需要添加价格
    if (orderType === 'LO' && price) {
      orderParams.submittedPrice = new Decimal(parseFloat(price).toString());
    }
    
    console.log('📦 订单参数:', {
      symbol: orderParams.symbol,
      orderType: orderParams.orderType,
      side: orderParams.side,
      quantity: orderParams.quantity.toString(),
      submittedQuantity: orderParams.submittedQuantity.toString(),
      timeInForce: orderParams.timeInForce,
      outsideRth: orderParams.outsideRth,
      submittedPrice: orderParams.submittedPrice ? orderParams.submittedPrice.toString() : undefined
    });
    
    const order = await trade.submitOrder(orderParams);
    
    console.log(`✅ 订单提交成功:`, JSON.stringify(order, null, 2));
    res.json({ success: true, data: order });
  } catch (error) {
    console.error('❌ 订单提交失败:', error.message);
    res.json({ success: false, error: error.message });
  }
});

// ========== 自动交易策略 ==========
// 自动交易配置（可手动修改默认值）
let autoTradingConfig = {
  enabled: false,                          // 开关状态
  mode: 'all',                             // 模式: all-自动交易(完整流程), buy-只买入, stopLoss-只止损, sell-只卖出
  buyTime: '21:50',                        // 买入时间（美股盘中时间，默认晚上9:50）
  buyDate: new Date().toISOString().split('T')[0], // 买入日期
  buyTomorrow: false,                      // 次日期权开关（true=买明天，false=买今天）
  optionType: 'QQQ_C',                      // 期权类型: QQQ_C(QQQ看涨), QQQ_P(QQQ看跌), SPY_C(SPY看涨), SPY_P(SPY看跌)
  buyQuantity: 1,                          // 买入张数
  maxOptionPrice: 0.6,                     // 买入期权最高价格，优先买接近这个价格的期权
  stopLossTime: '22:20',                    // 止损时间检测（具体时间）
  stopLossPrice: 0.25,                      // 止损价格，低于此价格止损
  sellTime: '23:20'                         // 卖出时间（具体时间）
};

let hasExecutedBuy = false;
let hasExecutedStopLoss = false;
let hasExecutedSell = false;

// 自动交易检查
async function runAutoTrading() {
  const now = new Date();
  const hours = now.getHours();
  const minutes = now.getMinutes();
  const totalMinutes = hours * 60 + minutes;
  const todayStr = now.toISOString().split('T')[0];
  
  // 如果自动交易未开启，跳过执行
  if (!autoTradingConfig.enabled) {
    console.log('🔴 自动交易已关闭，跳过执行');
    return;
  }
  
  // 只有开启时才打印详细日志
  console.log(`\n⏰ 自动交易检查 - 当前时间: ${hours}:${minutes.toString().padStart(2, '0')} (${totalMinutes}分钟)`);
  console.log(`🎯 当前模式: ${autoTradingConfig.mode}`);
  console.log('🟢 自动交易已开启');
  
  // 解析时间
  const [buyHour, buyMin] = autoTradingConfig.buyTime.split(':').map(Number);
  const buyTotalMinutes = buyHour * 60 + buyMin;
  const [stopLossHour, stopLossMin] = autoTradingConfig.stopLossTime.split(':').map(Number);
  const stopLossTotalMinutes = stopLossHour * 60 + stopLossMin;
  const [sellHour, sellMin] = autoTradingConfig.sellTime.split(':').map(Number);
  const sellTotalMinutes = sellHour * 60 + sellMin;
  
  // 检查是否是配置的买入日期
  const isBuyDate = todayStr === autoTradingConfig.buyDate;
  
  console.log(`📅 配置日期: ${autoTradingConfig.buyDate}, 今天: ${todayStr}, 匹配: ${isBuyDate}`);
  console.log(`⏰ 买入时间: ${autoTradingConfig.buyTime} (${buyTotalMinutes}分钟)`);
  console.log(`🔥 止损时间: ${autoTradingConfig.stopLossTime} (${stopLossTotalMinutes}分钟)`);
  console.log(`💰 卖出时间: ${autoTradingConfig.sellTime} (${sellTotalMinutes}分钟)`);
  console.log(`📈 次日期权: ${autoTradingConfig.buyTomorrow ? '✅ 是（买明天到期）' : '❌ 否（买今天到期）'}`);
  console.log(`🔢 买入张数: ${autoTradingConfig.buyQuantity}`);
  console.log(`🎯 期权类型: ${autoTradingConfig.optionType}`);
  
  // 买入策略（模式为all或buy时执行）
  const shouldBuy = autoTradingConfig.mode === 'all' || autoTradingConfig.mode === 'buy';
  const inBuyWindow = totalMinutes >= buyTotalMinutes && totalMinutes < buyTotalMinutes + 10;
  
  console.log(`\n--- 买入检查 ---`);
  console.log(`模式允许买入: ${shouldBuy ? '✅' : '❌'}`);
  console.log(`日期匹配: ${isBuyDate ? '✅' : '❌'}`);
  console.log(`在买入时间窗口内 (${buyTotalMinutes}-${buyTotalMinutes+10}分钟): ${inBuyWindow ? '✅' : '❌'}`);
  console.log(`尚未执行买入: ${!hasExecutedBuy ? '✅' : '❌'}`);
  
  if (shouldBuy && isBuyDate && inBuyWindow && !hasExecutedBuy) {
    console.log('🚀 开始执行买入策略...');
    await executeBuyStrategy();
    hasExecutedBuy = true;
  } else if (!shouldBuy) {
    console.log('⚠️ 当前模式不允许买入');
  } else if (!isBuyDate) {
    console.log('⚠️ 日期不匹配，跳过买入');
  } else if (!inBuyWindow) {
    console.log(`⚠️ 当前时间不在买入窗口内，距离买入时间还有 ${buyTotalMinutes - totalMinutes > 0 ? buyTotalMinutes - totalMinutes : '已过'} 分钟`);
  } else if (hasExecutedBuy) {
    console.log('⚠️ 今日已执行过买入，跳过');
  }
  
  // 止损检查（模式为all或stopLoss时执行）
  const shouldStopLoss = autoTradingConfig.mode === 'all' || autoTradingConfig.mode === 'stopLoss';
  const stopLossCheck = shouldStopLoss && isBuyDate && totalMinutes >= stopLossTotalMinutes && totalMinutes < stopLossTotalMinutes + 10 && !hasExecutedStopLoss;
  
  console.log(`\n--- 止损检查 ---`);
  console.log(`模式允许止损: ${shouldStopLoss ? '✅' : '❌'}`);
  console.log(`在止损时间窗口内: ${totalMinutes >= stopLossTotalMinutes && totalMinutes < stopLossTotalMinutes + 10 ? '✅' : '❌'}`);
  console.log(`尚未执行止损: ${!hasExecutedStopLoss ? '✅' : '❌'}`);
  
  if (stopLossCheck) {
    console.log('🔥 开始执行止损检查...');
    await executeStopLoss();
    hasExecutedStopLoss = true;
  }
  
  // 卖出策略（模式为all或sell时执行）
  const shouldSell = autoTradingConfig.mode === 'all' || autoTradingConfig.mode === 'sell';
  const sellCheck = shouldSell && isBuyDate && totalMinutes >= sellTotalMinutes && totalMinutes < sellTotalMinutes + 10 && !hasExecutedSell;
  
  console.log(`\n--- 卖出检查 ---`);
  console.log(`模式允许卖出: ${shouldSell ? '✅' : '❌'}`);
  console.log(`在卖出时间窗口内: ${totalMinutes >= sellTotalMinutes && totalMinutes < sellTotalMinutes + 10 ? '✅' : '❌'}`);
  console.log(`尚未执行卖出: ${!hasExecutedSell ? '✅' : '❌'}`);
  
  if (sellCheck) {
    console.log('💰 开始执行卖出策略...');
    await executeSellStrategy();
    hasExecutedSell = true;
  }
  
  // 00:00 重置标志，准备下一天
  if (totalMinutes >= 1440 || totalMinutes < 60) {
    console.log('🌙 午夜重置，准备新的一天');
    hasExecutedBuy = false;
    hasExecutedStopLoss = false;
    hasExecutedSell = false;
  }
}

// 买入策略
async function executeBuyStrategy() {
  try {
    // 根据期权类型决定持仓检查逻辑
    const optionTypeMap = {
      'QQQ_C': { symbol: 'QQQ', optionType: 'C' },
      'QQQ_P': { symbol: 'QQQ', optionType: 'P' },
      'SPY_C': { symbol: 'SPY', optionType: 'C' },
      'SPY_P': { symbol: 'SPY', optionType: 'P' },
      'GC_C': { symbol: 'GC', optionType: 'C' },
      'GC_P': { symbol: 'GC', optionType: 'P' }
    };
    const config = optionTypeMap[autoTradingConfig.optionType] || optionTypeMap['QQQ_C'];
    const optionName = { 'C': 'Call', 'P': 'Put' };
    
    // 检查是否已持有对应类型的期权
    const positions = await getAllPositions();
    const hasPosition = positions.some(p => 
      p.symbol && p.symbol.includes(config.symbol) && p.symbol.includes(config.optionType)
    );
    
    if (hasPosition) {
      console.log(`⚠️ 已持有 ${config.symbol} ${optionName[config.optionType]} 期权，跳过买入`);
      return;
    }
    
    // 获取期权链
    const options = await getQQQCallOptions();
    console.log(`📊 可用 ${optionName[config.optionType]} 期权数量: ${options.length}`);
    
    const maxPrice = autoTradingConfig.maxOptionPrice;
    console.log(`🎯 最高期权价格配置: $${maxPrice}`);
    
    // 按价格接近程度筛选（优先买接近最高价格的期权，没有则向下匹配）
    const sortedOptions = options
      .filter(o => o.lastPrice > 0 && o.lastPrice <= maxPrice)
      .sort((a, b) => Math.abs(a.lastPrice - maxPrice) - Math.abs(b.lastPrice - maxPrice));
    
    console.log(`📊 符合价格条件 (≤$${maxPrice}) 的期权: ${sortedOptions.length} 个`);
    
    // 打印前5个最接近的期权
    sortedOptions.slice(0, 5).forEach((o, i) => {
      console.log(`  ${i + 1}. ${o.symbol} @ $${o.lastPrice.toFixed(2)} (差距: $${Math.abs(o.lastPrice - maxPrice).toFixed(2)})`);
    });
    
    let selectedOption = null;
    if (sortedOptions.length > 0) {
      // 选择最接近目标价格的期权
      selectedOption = sortedOptions[0];
      console.log(`✅ 选择期权: ${selectedOption.symbol} @ $${selectedOption.lastPrice.toFixed(2)}`);
    }
    
    if (selectedOption) {
      await placeOrder(selectedOption.symbol, 'Buy', autoTradingConfig.buyQuantity, 'MO');
    } else {
      console.log('❌ 没有找到符合条件的期权');
    }
  } catch (error) {
    console.error('❌ 买入策略执行失败:', error.message);
  }
}

// 止损策略
async function executeStopLoss() {
  try {
    // 根据期权类型决定持仓检查逻辑
    const optionTypeMap = {
      'QQQ_C': { symbol: 'QQQ', optionType: 'C' },
      'QQQ_P': { symbol: 'QQQ', optionType: 'P' },
      'SPY_C': { symbol: 'SPY', optionType: 'C' },
      'SPY_P': { symbol: 'SPY', optionType: 'P' },
      'GC_C': { symbol: 'GC', optionType: 'C' },
      'GC_P': { symbol: 'GC', optionType: 'P' }
    };
    const config = optionTypeMap[autoTradingConfig.optionType] || optionTypeMap['QQQ_C'];
    const optionName = { 'C': 'Call', 'P': 'Put' };
    const stopLossPrice = autoTradingConfig.stopLossPrice || 0.25;
    
    const positions = await getAllPositions();
    const optionPositions = positions.filter(p => 
      p.symbol && p.symbol.includes(config.symbol) && p.symbol.includes(config.optionType)
    );
    
    if (optionPositions.length === 0) {
      console.log(`📭 没有持有 ${config.symbol} ${optionName[config.optionType]} 期权，跳过止损检查`);
      return;
    }
    
    // 获取实时报价
    const symbols = optionPositions.map(p => p.symbol);
    const quote = await getQuoteContext();
    const quotes = await quote.optionQuote(symbols);
    
    for (const pos of optionPositions) {
      const q = quotes.find(o => o.symbol === pos.symbol);
      const currentPrice = q ? parseFloat(q.lastDone) : null;
      
      console.log(`📊 ${pos.symbol} 当前价格: $${currentPrice || 'N/A'}`);
      
      if (currentPrice !== null && currentPrice < stopLossPrice) {
        console.log(`🔥 止损触发! ${pos.symbol} 价格 $${currentPrice} < $${stopLossPrice}`);
        await placeOrder(pos.symbol, 'Sell', parseInt(pos.quantity) || 1, 'MO');
      } else {
        console.log(`✅ ${pos.symbol} 价格 $${currentPrice} >= $${stopLossPrice}，继续持有`);
      }
    }
  } catch (error) {
    console.error('❌ 止损策略执行失败:', error.message);
  }
}

// 卖出策略
async function executeSellStrategy() {
  try {
    // 根据期权类型决定持仓检查逻辑
    const optionTypeMap = {
      'QQQ_C': { symbol: 'QQQ', optionType: 'C' },
      'QQQ_P': { symbol: 'QQQ', optionType: 'P' },
      'SPY_C': { symbol: 'SPY', optionType: 'C' },
      'SPY_P': { symbol: 'SPY', optionType: 'P' },
      'GC_C': { symbol: 'GC', optionType: 'C' },
      'GC_P': { symbol: 'GC', optionType: 'P' }
    };
    const config = optionTypeMap[autoTradingConfig.optionType] || optionTypeMap['QQQ_C'];
    const optionName = { 'C': 'Call', 'P': 'Put' };
    
    const positions = await getAllPositions();
    const optionPositions = positions.filter(p => 
      p.symbol && p.symbol.includes(config.symbol) && p.symbol.includes(config.optionType)
    );
    
    if (optionPositions.length === 0) {
      console.log(`📭 没有持有 ${config.symbol} ${optionName[config.optionType]} 期权，跳过卖出`);
      return;
    }
    
    for (const pos of optionPositions) {
      console.log(`💰 卖出期权: ${pos.symbol}`);
      await placeOrder(pos.symbol, 'Sell', parseInt(pos.quantity) || 1, 'MO');
    }
  } catch (error) {
    console.error('❌ 卖出策略执行失败:', error.message);
  }
}

// 获取所有持仓
async function getAllPositions() {
  const trade = await getTradeContext();
  const positions = await trade.stockPositions();
  
  let allPositions = [];
  if (positions && positions.channels && Array.isArray(positions.channels)) {
    positions.channels.forEach(channel => {
      if (channel.positions && Array.isArray(channel.positions)) {
        allPositions = allPositions.concat(channel.positions);
      }
    });
  }
  return allPositions;
}

// 获取 QQQ Call 期权
async function getQQQCallOptions() {
  try {
    const quote = await getQuoteContext();
    const today = new Date();
    
    // 根据buyTomorrow开关决定查询今天还是明天的期权
    let targetDate = new Date(today);
    if (autoTradingConfig.buyTomorrow) {
      targetDate.setDate(today.getDate() + 1);
    }
    
    // 根据期权类型决定标的和期权类型
    const optionTypeMap = {
      'QQQ_C': { symbol: 'QQQ.US', optionType: 'C' },
      'QQQ_P': { symbol: 'QQQ.US', optionType: 'P' },
      'SPY_C': { symbol: 'SPY.US', optionType: 'C' },
      'SPY_P': { symbol: 'SPY.US', optionType: 'P' },
      'GC_C': { symbol: 'GC', optionType: 'C' },
      'GC_P': { symbol: 'GC', optionType: 'P' }
    };
    const config = optionTypeMap[autoTradingConfig.optionType] || optionTypeMap['QQQ_C'];
    const optionName = { 'C': '看涨', 'P': '看跌' };
    
    const targetDateStr = targetDate.toISOString().split('T')[0];
    console.log(`📅 查询期权日期: ${targetDateStr} (${autoTradingConfig.buyTomorrow ? '明日' : '今日'})`);
    console.log(`🎯 期权配置: ${autoTradingConfig.optionType} (${config.symbol}, ${optionName[config.optionType]})`);
    
    // 获取期权链
    console.log(`🔄 正在查询期权链: ${config.symbol} @ ${targetDateStr}`);
    const chain = await quote.optionChainInfoByDate(
      config.symbol, 
      new NaiveDate(targetDate.getFullYear(), targetDate.getMonth() + 1, targetDate.getDate())
    );
    
    console.log(`📥 期权链返回: ${chain.length} 条记录`);
    
    // 根据期权类型获取 Call 或 Put 期权代码
    const filterKey = config.optionType === 'C' ? 'callSymbol' : 'putSymbol';
    const optionSymbols = chain
      .filter(opt => opt[filterKey] && opt[filterKey].includes(config.optionType))
      .map(opt => opt[filterKey]);
    
    console.log(`📡 获取 ${optionSymbols.length} 个 ${optionName[config.optionType]} 期权报价...`);
    
    if (optionSymbols.length === 0) {
      console.log(`⚠️ 没有找到 ${config.symbol} ${optionName[config.optionType]} 期权`);
      return [];
    }
    
    // 获取实时报价
    const quotes = await quote.optionQuote(optionSymbols);
    console.log(`📊 实时报价返回: ${quotes.length} 条`);
    
    // 解析期权信息，过滤价格低于0.10的期权
    const filteredQuotes = quotes.map(q => ({
      symbol: q.symbol,
      lastPrice: parseFloat(q.lastDone) || 0,
      strike: q.symbol.match(/[CP](\d{6})\.US$/) ? 
        parseFloat(q.symbol.match(/[CP](\d{6})\.US$/)[1]) / 1000 : 0
    })).filter(opt => opt.lastPrice >= 0.10);
    
    console.log(`🔍 过滤后剩余 ${filteredQuotes.length} 个期权（价格≥$0.10）`);
    
    if (filteredQuotes.length === 0) {
      console.log(`⚠️ 过滤后没有符合条件的期权（价格≥$0.10）`);
    }
    
    return filteredQuotes;
  } catch (error) {
    console.error('❌ getQQQCallOptions 执行失败:', error.message);
    console.error('❌ 错误堆栈:', error.stack);
    return [];
  }
}

// 下单函数
async function placeOrder(symbol, side, quantity, orderType) {
  const trade = await getTradeContext();
  
  const orderTypeMap = { 'MO': 3, 'LO': 1 };
  const sideMap = { 'Buy': 1, 'Sell': 2 };
  
  const orderParams = {
    symbol,
    orderType: orderTypeMap[orderType] || 0,
    side: sideMap[side] || 1,
    quantity: new Decimal(quantity.toString()),
    submittedQuantity: new Decimal(quantity.toString()),
    timeInForce: 1 // Day
  };
  
  try {
    const order = await trade.submitOrder(orderParams);
    console.log(`✅ 订单提交成功: ${side} ${symbol} x ${quantity}`);
    return order;
  } catch (error) {
    console.error(`❌ 订单提交失败: ${error.message}`);
    return null;
  }
}

// 根据当前秒数初始化计数器，实现与实际时间对齐
const initCounter = () => {
  const seconds = new Date().getSeconds();
  if (seconds >= 0 && seconds <= 9) return 0;
  if (seconds >= 10 && seconds <= 19) return 1;
  if (seconds >= 20 && seconds <= 29) return 2;
  if (seconds >= 30 && seconds <= 39) return 3;
  if (seconds >= 40 && seconds <= 49) return 4;
  return 5; // 50-59秒
};

let autoTradingCounter = initCounter();
console.log(`🚀 自动交易启动 - 当前秒数: ${new Date().getSeconds()}, 初始化计数器: ${autoTradingCounter}`);

setInterval(() => {
  autoTradingCounter++;
  if (autoTradingCounter >= 6) {
    autoTradingCounter = 0;
  }
  // console.log(`🔄 自动交易循环 - 计数器: ${autoTradingCounter}`);
  if (autoTradingCounter === 1) {
    runAutoTrading();
  }
}, 10000);

// 立即执行一次检查
runAutoTrading();

// ========== 路由处理 ==========
// 根路径 - 老九
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// /v2 路径 - 君悦
app.get('/v2', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`\n========================================`);
  console.log(`✅ 服务器启动成功！`);
  console.log(`========================================`);
  console.log(`👤 老九: http://localhost:${PORT}/`);
  console.log(`👤 君悦: http://localhost:${PORT}/v2`);
  console.log(`========================================\n`);
});
