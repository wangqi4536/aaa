const express = require('express');
const cors = require('cors');
const { Config, TradeContext, QuoteContext, NaiveDate,  OrderType, OrderSide, TimeInForceType, Decimal } = require('longport');

const app = express();

app.use(cors());
app.use(express.json());
// 支持从 public 目录或根目录提供静态文件
const path = require('path');
app.use(express.static('public'));
app.use(express.static(__dirname));

// ========== 用户配置 ==========
// 从命令行参数获取用户和端口
const userArg = process.argv[2] || 'laojiu';
const PORT = parseInt(process.argv[3]) || 3000;

// 用户配置映射
const userConfig = {
  laojiu: {
    name: '老九',
    realConfig: null,
    paperConfig: null
  },
  junyue: {
    name: '君悦',
    realConfig: null,
    paperConfig: null
  }
};

// 获取当前用户
const currentUser = userConfig[userArg] || userConfig.laojiu;

// 打印启动信息
console.log(`\n========================================`);
console.log(`👤 当前用户: ${currentUser.name}`);
console.log(`📌 启动命令: ${userArg}`);
console.log(`🔌 监听端口: ${PORT}`);
console.log(`========================================\n`);

// ========== 环境配置 ==========
// 修改这里切换默认环境：'paper' = 模拟盘, 'real' = 正式盘
let currentEnvironment = 'paper'; // 默认使用模拟盘

// 正式盘配置
const realConfig = new Config({
  appKey: "a640c4404d79114fb23b3f76ffc04176",
  appSecret: "507e944129f096fb00a1db98916b2db21803c7d62a77fb57a00338217ac8b9af",
  enablePrintQuotePackages: false,
  accessToken: "m_eyJhbGciOiJSUzI1NiIsImtpZCI6ImQ5YWRiMGIxYTdlNzYxNzEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJsb25nYnJpZGdlIiwic3ViIjoiYWNjZXNzX3Rva2VuIiwiZXhwIjoxNzg4NDMzMjIwLCJpYXQiOjE3ODA2NTcyMjEsImFrIjoiYTY0MGM0NDA0ZDc5MTE0ZmIyM2IzZjc2ZmZjMDQxNzYiLCJhYWlkIjoyMDQ5Njg0NCwiYWMiOiJsYiIsIm1pZCI6MTU5NTMyOTksInNpZCI6ImZSYjlvSmFOZSthbkc4NHZ6blpWMUE9PSIsImJsIjozLCJ1bCI6MCwiaWsiOiJsYl8yMDQ5Njg0NCJ9.pMSChJOZX4TKFn4QAIWHfapEOVzweK6jqgd6ua86m_J6Ao5tCgEXRXrDwvb8KaEafrz66jcjKnLR08fETUY7vMkAjeGMcaYoFjTeZP7zenvFzN96Bkyyk31fFDSarAUSvazI73bv8tgRd9KUhHy_z9Zp8_B2wsf3stDFVMAg4PyuokYb9OQqpPK3mGr1zdjviyZqYRFdIgSpMIjZHfqWc3BZ8s9WTqAJy5ttVhjg7PE8A2fpBqiw4-kd3_9rjRkafT7QJeL3MKVWPxOZQ3RKFfUq8BEGPZ13eq2nir4NczTvL7kDT0pZbxOa82-grXxl1rULzN0vLXuZQZXK61VPE9_BzifXZtqCWyTnRP1L8-KR5p8GzxbExvGQV6fzUVIa5aZVjCST-tOYqz1WIaD5aWmnQ6G9-igR6umFUysJsj6ARseblLyq46HfU5R2xkAYGOq2ZH0Y6_RCT9m2imqOV-iVZrj80pUeXshkjbWUzVtAls-ZhxLW9ojfj-VdLvAyjPOHiwW2SCR0mIGv0FOF_6oLWXBCCKroxlhwfDSbWJ6RhLNb7twO4QHTbFET8osErphl-dnsLff7S9qtzzkDE4nIAo9IrohKfQxOqTh21I-tyPVD3vALH-T0VssoOV5sEFbLWI9sCAI4Rq3Xfi9v70vo97pYyBAOeMw7oa4iX6w"
});

// 模拟盘配置
const paperConfig = new Config({
  appKey: "a640c4404d79114fb23b3f76ffc04176",
  appSecret: "507e944129f096fb00a1db98916b2db21803c7d62a77fb57a00338217ac8b9af",
  enablePrintQuotePackages: false,
  accessToken: "m_eyJhbGciOiJSUzI1NiIsImtpZCI6ImQ5YWRiMGIxYTdlNzYxNzEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJsb25nYnJpZGdlIiwic3ViIjoiYWNjZXNzX3Rva2VuIiwiZXhwIjoxNzg4NDMzNjUyLCJpYXQiOjE3ODA2NTc2NTMsImFrIjoiYTY0MGM0NDA0ZDc5MTE0ZmIyM2IzZjc2ZmZjMDQxNzYiLCJhYWlkIjoyMDUzMjY5NiwiYWMiOiJsYl9wYXBlcnRyYWRpbmciLCJtaWQiOjE1OTUzMjk5LCJzaWQiOiJFTWp0aW12RkpPUW9iZzBvZ3laMXFnPT0iLCJibCI6MywidWwiOjAsImlrIjoibGJfcGFwZXJ0cmFkaW5nXzIwNTMyNjk2In0.oGTXzpPG7BOWrut7PtoGRi9nX2zb8GWltURehYtVQe0oZjNdawBDWlQlaBwRjFAWDHKiMo9ZPj9FXVItaqcyBn_eQfYLOgIChHF91dWgqe3mfdxj7A_CDMPrp7omCZCq8TXzPDrijO_0o-Kmz8ERaXQXoRnK_BPQ2b4x6o-3RIUta0mm2OO7HIc7aBoawMBETsN6QpdSX4ksJ72AviPQ_lzk87y-OmpAh2cilX10mthdhp0XbWI-aEvbTrEIXQB_ngTPdUzaYfIDx3DPrx80DedW-BNHCNZxcIGquBs3wXuVI3yHmIydAtkvr3yCqI3hqaqVu93q-vfr7vdFl_5I71mjjyxqzc_WmUdGn8TTGGkqoensbxo52kEteG7A0cIDpr09nT0h5oSy2viEFzfow-mDsJwp1DTJ9D9mi-HgamqINI8etJiQ9JtAYnSu5YXsg6mCJm8Gj3Os3dAGqioy-A8WbFQnZu4y4ZgHJO6u_naErxjwPTlsb-ofVKVwBtpuWqqY3lqdMrFVh-eoi7RxZqmpphcSwy-mfDkBpdkuw6YjwHRAJvAvuemWGp-1KOG4qo_GHCVtoruoW0JglE8SLqqDcHqeP9D4maXB7Bp-U0R8OA_d0WLkWKisUwmHVGgzagDeFH3DlkM2WA19yUyU7_aF3sqb5F1kmGxQa1Hsouk"
});

// 正式盘2配置
const realConfig2 = new Config({
  appKey: "5c5c00f07e7ebbe75775e786163a55ce",
  appSecret: "a93214d28e01fdf22534d379b46cd151c729421cd7e9ff8391df85980275c869",
  enablePrintQuotePackages: false,
  accessToken: "m_eyJhbGciOiJSUzI1NiIsImtpZCI6ImQ5YWRiMGIxYTdlNzYxNzEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJsb25nYnJpZGdlIiwic3ViIjoiYWNjZXNzX3Rva2VuIiwiZXhwIjoxNzg4NzEyMjIzLCJpYXQiOjE3ODA5MzYyMjMsImFrIjoiNWM1YzAwZjA3ZTdlYmJlNzU3NzVlNzg2MTYzYTU1Y2UiLCJhYWlkIjoyMDU0NDcwOSwiYWMiOiJsYiIsIm1pZCI6MTYzMzE0MzMsInNpZCI6ImF5THY0M0Z6SWNONmU4Nys0OXV1MFE9PSIsImJsIjozLCJ1bCI6MCwiaWsiOiJsYl8yMDU0NDcwOSJ9.2sBH0NpCIRDjRtn6m5qNRVUGMKc0CDbKtgS07mPi5RTKzVhyXTxWwQEtnaris7DSx3D5VILwjjXQOt1SEaCNm4fT1SqtmZawKaICpettjeZvTEfhZKWn0UmBudV6JnJz6BpuOnfny5VWRtmN2BWAvNmC7DHi6n4sPs4k7d-O2_9CQvnahSRJbWCFqmOTmSwBsps_z7JWhefKdNZtc9TXeDX2KWCSKYb1IzNDXF611blVyDZ9nz1j96u8uOAPUU-vWB0-5npfetMJge0KhHd2pvw3-4tsSLL6grSZ5GcUWlS9dc5ogyq1nAiT6MTia88SY6RZCimxSZRzzpvEVFC8Sri51O8dJXciRuL5WPF9L90mytF-VtwLExE_PZnyOWgX83xo8saInlWmZ4iI6-eC5ZX4Bgb3PJ5VkuagTSi2lnIX9yBlevtZGWxOmW8DA_SdDJ8yPbLrDannYa920alMajhEv4OgFwEV48TQFr5OCtyswy39UFv6N_ljzsGIy-idkxbKzVVHdJtV42tg5W19TNwD9QjaX2Eh1o9jY3k3NQMtXx8dCbzFIXaD8fpfzHUgPJA8wZdXC1dslX3LXlbnA-aoZW_K0uIvueLS51-vdIDZyU4J-WInHaEY2ovhcRnIMZL3DnlD7r2s5wwJFN7yW3q-6L8jpEkUjlCXDd-g5Rc"
});

// 模拟盘2配置
const paperConfig2 = new Config({
  appKey: "5c5c00f07e7ebbe75775e786163a55ce",
  appSecret: "a93214d28e01fdf22534d379b46cd151c729421cd7e9ff8391df85980275c869",
  enablePrintQuotePackages: false,
  accessToken: "m_eyJhbGciOiJSUzI1NiIsImtpZCI6ImQ5YWRiMGIxYTdlNzYxNzEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJsb25nYnJpZGdlIiwic3ViIjoiYWNjZXNzX3Rva2VuIiwiZXhwIjoxNzgyNDY5Mjg4LCJpYXQiOjE3NzQ2OTMyODgsImFrIjoiNWM1YzAwZjA3ZTdlYmJlNzU3NzVlNzg2MTYzYTU1Y2UiLCJhYWlkIjoyMDc0OTc4MCwiYWMiOiJsYl9wYXBlcnRyYWRpbmciLCJtaWQiOjE2MzMxNDMzLCJzaWQiOiI0R0d6aVF6ZzNzV2xXT0xWRkNXb2tBPT0iLCJibCI6MywidWwiOjAsImlrIjoibGJfcGFwZXJ0cmFkaW5nXzIwNzQ5NzgwIn0.fiTKuImms3RBrCgUyru3d9Vl-VwgS2E4w4mRxKpjlN4KTugH_zyjH8vVeN9TJW3h8_HI_QGtRYkb7KFu9FkIZigjQl_2eLQ0QLcYHKZwdmeWk43WEFPe-_LtoUesX5jwJT8OQB8X9e_3_lrPzMwI5RPOv-7aPkObjpu1Bx25ouL-kDMT0jNrYKb55W8keIZLeJl_EJeyE0KPJhTn1CYcIQD5DXvSGykGomvJFBPr_kp0Gmydge6gop1zD20PcbJUNV4e96d8DUyubT8KGSSoRtoG--Wo4BPQTzcRvyhEvud_wP5AcfnU6nEBJBqECNkd_MLIWKs1L0CkgY5OI06EYmeC7Aee_jH_McNVs251yiIR_aIztI60tsKqOvi0WIbDzXgWYuizR0v1XTrHUWZ0joJtIt3Z8oKDmxMiJZnboJHyMTetBjXiTFfpQgx0uzCiBijg-g6JsqSE2r8_KZGiOwYMYJRLRAq9atgCQ24pvTELD1Uz9f2oC0lMCR0JlEgmWXqFuwoPpitSoB-KmGxAC5ymHXhpDsTvhzO3SoFWiPDDIFhBeGdMfq7yqpb0xV1zN0M7kSI2ZUoPxn4gqcSz3QUfx1bRfnXqWiyX37kgWrUAeFRHJ4vSoHUImNEg4YLMaZ1Udml9p5An1WIOTDxUVQV_O46vwrznmBbRRyhuz-k"
});

// 更新用户配置映射
userConfig.laojiu.realConfig = realConfig;
userConfig.laojiu.paperConfig = paperConfig;
userConfig.junyue.realConfig = realConfig2;
userConfig.junyue.paperConfig = paperConfig2;

// 重新获取当前用户（配置已更新）
const activeUser = userConfig[userArg] || userConfig.laojiu;


// 获取当前配置
function getCurrentConfig() {
  return currentEnvironment === 'paper' ? activeUser.paperConfig : activeUser.realConfig;
}

// 全局单例实例
let quoteCtx = null;
let tradeCtx = null;

async function getQuoteContext() {
  if (!quoteCtx) {
    quoteCtx = await QuoteContext.new(getCurrentConfig());
    console.log(`✅ QuoteContext 实例已创建 (${activeUser.name} - ${currentEnvironment === 'paper' ? '模拟盘' : '正式盘'})`);
  }
  return quoteCtx;
}

async function getTradeContext() {
  if (!tradeCtx) {
    tradeCtx = await TradeContext.new(getCurrentConfig());
    console.log(`✅ TradeContext 实例已创建 (${activeUser.name} - ${currentEnvironment === 'paper' ? '模拟盘' : '正式盘'})`);
  }
  return tradeCtx;
}

// 切换环境并重置连接
function switchEnvironment(env) {
  if (env === 'paper' || env === 'real') {
    currentEnvironment = env;
    quoteCtx = null; // 重置连接
    tradeCtx = null; // 重置连接
    console.log(`🔄 ${activeUser.name} - 环境已切换至: ${env === 'paper' ? '模拟盘' : '正式盘'}`);
    return true;
  }
  return false;
}

// API: 获取当前用户信息
app.get('/api/user', (req, res) => {
  res.json({
    success: true,
    data: {
      username: activeUser.name,
      userKey: userArg,
      environment: currentEnvironment === 'paper' ? '模拟盘' : '正式盘'
    }
  });
});

// API: 获取当前环境
app.get('/api/environment', (req, res) => {
  res.json({
    success: true,
    data: {
      environment: currentEnvironment,
      display: currentEnvironment === 'paper' ? '模拟盘' : '正式盘'
    }
  });
});

// API: 切换环境
app.post('/api/environment', (req, res) => {
  const { environment } = req.body;
  if (switchEnvironment(environment)) {
    res.json({
      success: true,
      data: {
        environment: currentEnvironment,
        display: currentEnvironment === 'paper' ? '模拟盘' : '正式盘'
      }
    });
  } else {
    res.json({
      success: false,
      error: '无效的环境参数，请使用 "paper" 或 "real"'
    });
  }
});

// API: 获取自动交易状态
app.get('/api/auto-trading/status', (req, res) => {
  res.json({ success: true, data: autoTradingEnabled });
});

// API: 切换自动交易状态
app.post('/api/auto-trading/toggle', (req, res) => {
  autoTradingEnabled = !autoTradingEnabled;
  console.log(`\n🔄 自动交易开关 ${autoTradingEnabled ? '🟢 已开启' : '🔴 已关闭'}`);
  res.json({ success: true, data: autoTradingEnabled });
});

app.get('/api/qqq-quote', async (req, res) => {
  try {
    const ctx = await getQuoteContext();
    const resp = await ctx.quote(['QQQ.US']);
    //console.log('📊 QQQ 实时行情:', JSON.stringify(resp, null, 2));
    res.json({ success: true, data: resp });
  } catch (error) {
    console.error('❌ QQQ 行情查询失败:', error.message);
    res.json({ success: false, error: error.message });
  }
});

app.get('/api/option-chain', async (req, res) => {
  try {
    const ctx = await getQuoteContext();
    const qqqQuote = await ctx.quote(['QQQ.US']);
    const qqqPriceFloat = parseFloat(qqqQuote[0].lastDone);
    const qqqPrice = Math.round(qqqPriceFloat);
    
    // 获取查询日期，默认今天
    let queryDate = new Date();
    if (req.query.date) {
      queryDate = new Date(req.query.date);
    }
    
    // 构建请求参数
    const requestParams = {
      symbol: 'QQQ.US',
      expiry: new NaiveDate(queryDate.getFullYear(), queryDate.getMonth() + 1, queryDate.getDate())
    };
    
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('📡 optionChainInfoByDate 请求参数:');
    console.log(JSON.stringify(requestParams, null, 2));
    console.log('查询日期:', queryDate.toISOString().split('T')[0]);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    
    const optionChain = await ctx.optionChainInfoByDate('QQQ.US', new NaiveDate(queryDate.getFullYear(), queryDate.getMonth() + 1, queryDate.getDate()));
    
    // 打印原始数据结构 - 详细打印
    console.log('📥 原始期权链数据 (共', optionChain.length, '条):');
    for (let i = 0; i < Math.min(optionChain.length, 3); i++) {
      const obj = optionChain[i];
      console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
      console.log('对象', i, ':', obj);
      console.log('对象属性:', Object.keys(obj));
      if (obj.toJSON) {
        console.log('toJSON结果:', obj.toJSON());
      }
      console.log('toString结果:', obj.toString());
    }
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    
    // 筛选符合行权价范围的期权（price是字符串类型）
    const filteredChain = optionChain.filter(opt => {
      const strike = parseInt(opt.price); // price是字符串，需要转换为数字
      const isCallInRange = strike >= qqqPrice && strike <= qqqPrice + 15;
      const isPutInRange = strike >= qqqPrice - 15 && strike <= qqqPrice;
      return isCallInRange || isPutInRange;
    });
    
    // 收集需要查询的期权代码
    const allSymbols = [];
    filteredChain.forEach(opt => {
      if (opt.callSymbol) allSymbols.push(opt.callSymbol);
      if (opt.putSymbol) allSymbols.push(opt.putSymbol);
    });
    
    console.log('📈 筛选后的期权信息:');
    console.log('  QQQ价格:', '$' + qqqPriceFloat, '→', '取整: $' + qqqPrice);
    console.log('  Call范围:', '$' + qqqPrice, '~', '$' + (qqqPrice + 15));
    console.log('  Put范围:', '$' + (qqqPrice - 15), '~', '$' + qqqPrice);
    console.log('  符合条件的期权代码数量:', allSymbols.length);
    console.log('  期权代码:', allSymbols);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    
    if (allSymbols.length > 0) {
      // 获取期权实时报价
      const optionQuotes = await ctx.optionQuote(allSymbols);
      
      // 分类整理 Call 和 Put
      const calls = [];
      const puts = [];
      
      // 构建期权数据（包含行权价）
      // symbol格式: QQQ260608C930000.US 或 QQQ260608P505000.US
      optionQuotes.forEach(quote => {
        // 提取行权价：930000 → 930
        const strikeMatch = quote.symbol.match(/[CP](\d{6})\.US$/);
        let strike = 0;
        if (strikeMatch) {
          strike = parseInt(strikeMatch[1]) / 1000; // 930000 → 930
        }
        
        const optData = {
          symbol: quote.symbol,
          lastDone: quote.lastDone,
          strike: strike
        };
        
        if (quote.symbol.includes('C')) {
          calls.push(optData);
        } else {
          puts.push(optData);
        }
      });
      
      // 按行权价排序
      calls.sort((a, b) => a.strike - b.strike);
      puts.sort((a, b) => a.strike - b.strike);
      
      console.log('📊 整理后的期权数据:');
      console.log('  Call期权数量:', calls.length);
      console.log('  Put期权数量:', puts.length);
      console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
      
      res.json({ 
        success: true, 
        data: { 
          qqqPrice: qqqPriceFloat, 
          qqqPriceRounded: qqqPrice, 
          queryDate: queryDate.toISOString().split('T')[0],
          calls, 
          puts 
        } 
      });
    } else {
      console.log('📈 期权链查询 - QQQ价格: $' + qqqPrice + ', 无符合条件的期权');
      res.json({ 
        success: true, 
        data: { 
          qqqPrice: qqqPriceFloat, 
          qqqPriceRounded: qqqPrice, 
          queryDate: queryDate.toISOString().split('T')[0],
          calls: [], 
          puts: [] 
        } 
      });
    }
  } catch (error) {
    console.error('❌ 期权链查询失败:', error.message);
    res.json({ success: false, error: error.message });
  }
});

app.get('/api/available-dates', async (req, res) => {
  try {
    const dates = [];
    const today = new Date();
    
    // 生成从今天起往后35天的日期
    for (let i = 0; i < 35; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      dates.push({
        date: date.toISOString().split('T')[0],
        display: `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`,
        dayOfWeek: ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][date.getDay()]
      });
    }
    
    res.json({ success: true, data: dates });
  } catch (error) {
    res.json({ success: false, error: error.message });
  }
});

app.get('/api/positions', async (req, res) => {
  try {
    const trade = await getTradeContext();
    const quote = await getQuoteContext();
    const positions = await trade.stockPositions();
    
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('📡 stockPositions() 原始返回数据:');
    console.log('数据类型:', typeof positions);
    console.log('是否数组:', Array.isArray(positions));
    console.log('数据内容:', JSON.stringify(positions, null, 2));
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    
    // 正确处理嵌套数据结构: channels[].positions
    let allPositions = [];
    
    if (positions && positions.channels && Array.isArray(positions.channels)) {
      // 遍历所有渠道
      positions.channels.forEach(channel => {
        if (channel.positions && Array.isArray(channel.positions)) {
          allPositions = allPositions.concat(channel.positions);
        }
      });
    } else if (Array.isArray(positions)) {
      // 备用：如果直接返回数组
      allPositions = positions;
    } else if (positions && positions.stockPositions) {
      // 备用：如果在 stockPositions 字段中
      allPositions = positions.stockPositions;
    }
    
    console.log('📊 提取后的持仓数据:', JSON.stringify(allPositions, null, 2));
    res.json({ success: true, data: allPositions });
    // // 筛选 QQQ 期权持仓（symbol包含QQQ且包含.US）
    // const optionPositions = allPositions.filter(pos => 
    //   pos.symbol && pos.symbol.includes('QQQ')
    // );
    
    // console.log('🔍 筛选后的 QQQ 期权持仓:', JSON.stringify(optionPositions, null, 2));
    
    // if (optionPositions.length > 0) {
    //   const symbols = optionPositions.map(pos => pos.symbol);
    //   const optionQuotes = await quote.optionQuote(symbols);
      
    //   const enrichedPositions = optionPositions.map(pos => {
    //     const q = optionQuotes.find(o => o.symbol === pos.symbol);
    //     return { ...pos, quote: q };
    //   });
      
    //   console.log(`💼 持仓查询成功 - 找到 ${optionPositions.length} 个 QQQ 期权持仓`);
    //   console.log('持仓详情:', JSON.stringify(enrichedPositions, null, 2));
    //   res.json({ success: true, data: enrichedPositions });
    // } else {
    //   console.log('💼 持仓查询 - 暂无 QQQ 期权持仓');
    //   res.json({ success: true, data: [] });
    // }
  } catch (error) {
    console.error('❌ 持仓查询失败:', error.message);
    res.json({ success: false, error: error.message });
  }
});

app.post('/api/trade', async (req, res) => {
  try {
    const { symbol, side, quantity, orderType, price } = req.body;
    const trade = await getTradeContext();
    
    // 订单类型映射：字符串转数字枚举
    const orderTypeMap = {
      'MO': 3,  // 市价单 (Market Order)
      'LO': 1,  // 限价单 (Limit Order)
      'SC': 2,  // 止损单 (Stop Order)
      'SL': 4,  // 止损限价单 (Stop Limit Order)
    };
    
    // 订单方向映射：字符串转数字枚举
    const sideMap = {
      'Buy': 1,   // 买入
      'Sell': 2,  // 卖出
    };
    
    // 订单有效期映射：字符串转数字枚举
    const timeInForceMap = {
      'Day': 1,   // 当日有效
      'GTC': 2,   // 取消前有效 (Good Till Canceled)
      'IOC': 3,   // 立即执行或取消 (Immediate Or Cancel)
      'FOK': 4,   // 全部执行或取消 (Fill Or Kill)
    };
    
    const orderTypeValue = orderTypeMap[orderType] !== undefined ? orderTypeMap[orderType] : 0;
    const sideValue = sideMap[side] !== undefined ? sideMap[side] : 1;
    const timeInForceValue = timeInForceMap['Day']; // 默认当日有效
    const quantityNum = parseInt(quantity);
    
    console.log(`📝 提交订单 - 标的: ${symbol}, 方向: ${side} (${sideValue}), 数量: ${quantityNum}, 类型: ${orderType} (${orderTypeValue}), 有效期: Day (${timeInForceValue})${orderType === 'LO' ? `, 限价: $${price}` : ''}`);
    
    // 构建订单参数
    const orderParams = {
      symbol,
      orderType: orderTypeValue,
      side: sideValue,
      quantity: new Decimal(quantityNum.toString()),
      submittedQuantity: new Decimal(quantityNum.toString()),
      timeInForce: timeInForceValue,
    };
    
    // 限价单需要添加价格
    if (orderType === 'LO' && price) {
      orderParams.submittedPrice = new Decimal(parseFloat(price).toString());
    }
    
    console.log('📦 订单参数:', {
      symbol: orderParams.symbol,
      orderType: orderParams.orderType,
      side: orderParams.side,
      quantity: orderParams.quantity.toString(),
      submittedQuantity: orderParams.submittedQuantity.toString(),
      timeInForce: orderParams.timeInForce,
      submittedPrice: orderParams.submittedPrice ? orderParams.submittedPrice.toString() : undefined
    });
    
    const order = await trade.submitOrder(orderParams);
    
    console.log(`✅ 订单提交成功:`, JSON.stringify(order, null, 2));
    res.json({ success: true, data: order });
  } catch (error) {
    console.error('❌ 订单提交失败:', error.message);
    res.json({ success: false, error: error.message });
  }
});

// ========== 自动交易策略 ==========
// 09:50 买入 Call 期权（价格优先级：0.5-0.6 > 0.4-0.5 > 0.6-0.7）
// 10:30 检查价格，<0.25 止损
// 11:20 市价单卖出

let hasExecutedBuy = false;
let hasExecutedStopLoss = false;
let hasExecutedSell = false;

// 自动交易开关，默认关闭
let autoTradingEnabled = false;

// 自动交易检查
async function runAutoTrading() {
  const now = new Date();
  const hours = now.getHours();
  const minutes = now.getMinutes();
  const totalMinutes = hours * 60 + minutes;
  
  console.log(`\n⏰ 自动交易检查 - 当前时间: ${hours}:${minutes.toString().padStart(2, '0')} (${totalMinutes}分钟)`);
  
  // 如果自动交易未开启，跳过执行
  if (!autoTradingEnabled) {
    console.log('🔴 自动交易已关闭，跳过执行');
    return;
  }
  console.log('🟢 自动交易已开启');
  
  // // 21:30 买入策略 (晚上9:30 = 1290)
  // if (totalMinutes >= 1415 && totalMinutes < 1416 && !hasExecutedBuy) {
  //   console.log('🚀 开始执行买入策略...');
  //   await executeBuyStrategy();
  //   hasExecutedBuy = true;
  // }
  
  // // 22:30 止损检查 (晚上10:30 = 1350)
  // if (totalMinutes >= 1416 && totalMinutes < 1417 && !hasExecutedStopLoss) {
  //   console.log('🔥 开始执行止损检查...');
  //   await executeStopLoss();
  //   hasExecutedStopLoss = true;
  // }
  
  // // 23:20 卖出策略 (晚上11:20 = 1400)
  // if (totalMinutes >= 1417 && totalMinutes < 1418 && !hasExecutedSell) {
  //   console.log('💰 开始执行卖出策略...');
  //   await executeSellStrategy();
  //   hasExecutedSell = true;
  // }

  // 21:30 买入策略 (晚上9:50 = 1320)
  if (totalMinutes >= 1310 && totalMinutes < 1320 && !hasExecutedBuy) {
    console.log('🚀 开始执行买入策略...');
    await executeBuyStrategy();
    hasExecutedBuy = true;
  }
  
  // 22:30 止损检查 (晚上10:30 = 1350)
  if (totalMinutes >= 1350 && totalMinutes < 1360 && !hasExecutedStopLoss) {
    console.log('🔥 开始执行止损检查...');
    await executeStopLoss();
    hasExecutedStopLoss = true;
  }
  
  // 23:20 卖出策略 (晚上11:20 = 1400)
  if (totalMinutes >= 1400 && totalMinutes < 1410 && !hasExecutedSell) {
    console.log('💰 开始执行卖出策略...');
    await executeSellStrategy();
    hasExecutedSell = true;
  }
  
  // 00:00 重置标志，准备下一天
  if (totalMinutes >= 1440 || totalMinutes < 60) {
    hasExecutedBuy = false;
    hasExecutedStopLoss = false;
    hasExecutedSell = false;
  }
}

// 买入策略
async function executeBuyStrategy() {
  try {
    // 检查是否已持有期权
    const positions = await getAllPositions();
    const hasCallPosition = positions.some(p => 
      p.symbol && p.symbol.includes('QQQ') && p.symbol.includes('C')
    );
    
    if (hasCallPosition) {
      console.log('⚠️ 已持有 Call 期权，跳过买入');
      return;
    }
    
    // 获取期权链
    const options = await getQQQCallOptions();
    console.log(`📊 可用 Call 期权数量: ${options.length}`);
    
    // 按优先级筛选
    const priority1 = options.filter(o => o.lastPrice >= 0.5 && o.lastPrice < 0.6);
    const priority2 = options.filter(o => o.lastPrice >= 0.4 && o.lastPrice < 0.5);
    const priority3 = options.filter(o => o.lastPrice >= 0.6 && o.lastPrice < 0.7);
    
    console.log(`🎯 优先级1 (0.5-0.6): ${priority1.length} 个`);
    console.log(`🎯 优先级2 (0.4-0.5): ${priority2.length} 个`);
    console.log(`🎯 优先级3 (0.6-0.7): ${priority3.length} 个`);
    
    let selectedOption = null;
    if (priority1.length > 0) {
      selectedOption = priority1[0];
      console.log(`✅ 选择优先级1期权: ${selectedOption.symbol} @ $${selectedOption.lastPrice}`);
    } else if (priority2.length > 0) {
      selectedOption = priority2[0];
      console.log(`✅ 选择优先级2期权: ${selectedOption.symbol} @ $${selectedOption.lastPrice}`);
    } else if (priority3.length > 0) {
      selectedOption = priority3[0];
      console.log(`✅ 选择优先级3期权: ${selectedOption.symbol} @ $${selectedOption.lastPrice}`);
    }
    
    if (selectedOption) {
      await placeOrder(selectedOption.symbol, 'Buy', 1, 'MO');
    } else {
      console.log('❌ 没有找到符合条件的期权');
    }
  } catch (error) {
    console.error('❌ 买入策略执行失败:', error.message);
  }
}

// 止损策略
async function executeStopLoss() {
  try {
    const positions = await getAllPositions();
    const callPositions = positions.filter(p => 
      p.symbol && p.symbol.includes('QQQ') && p.symbol.includes('C')
    );
    
    if (callPositions.length === 0) {
      console.log('📭 没有持有 Call 期权，跳过止损检查');
      return;
    }
    
    // 获取实时报价
    const symbols = callPositions.map(p => p.symbol);
    const quote = await getQuoteContext();
    const quotes = await quote.optionQuote(symbols);
    
    for (const pos of callPositions) {
      const q = quotes.find(o => o.symbol === pos.symbol);
      const currentPrice = q ? parseFloat(q.lastDone) : null;
      
      console.log(`📊 ${pos.symbol} 当前价格: $${currentPrice || 'N/A'}`);
      
      if (currentPrice !== null && currentPrice < 0.25) {
        console.log(`🔥 止损触发! ${pos.symbol} 价格 $${currentPrice} < $0.25`);
        await placeOrder(pos.symbol, 'Sell', parseInt(pos.quantity) || 1, 'MO');
      } else {
        console.log(`✅ ${pos.symbol} 价格 $${currentPrice} >= $0.25，继续持有`);
      }
    }
  } catch (error) {
    console.error('❌ 止损策略执行失败:', error.message);
  }
}

// 卖出策略
async function executeSellStrategy() {
  try {
    const positions = await getAllPositions();
    const callPositions = positions.filter(p => 
      p.symbol && p.symbol.includes('QQQ') && p.symbol.includes('C')
    );
    
    if (callPositions.length === 0) {
      console.log('📭 没有持有 Call 期权，跳过卖出');
      return;
    }
    
    for (const pos of callPositions) {
      console.log(`💰 卖出期权: ${pos.symbol}`);
      await placeOrder(pos.symbol, 'Sell', parseInt(pos.quantity) || 1, 'MO');
    }
  } catch (error) {
    console.error('❌ 卖出策略执行失败:', error.message);
  }
}

// 获取所有持仓
async function getAllPositions() {
  const trade = await getTradeContext();
  const positions = await trade.stockPositions();
  
  let allPositions = [];
  if (positions && positions.channels && Array.isArray(positions.channels)) {
    positions.channels.forEach(channel => {
      if (channel.positions && Array.isArray(channel.positions)) {
        allPositions = allPositions.concat(channel.positions);
      }
    });
  }
  return allPositions;
}

// 获取 QQQ Call 期权
async function getQQQCallOptions() {
  const quote = await getQuoteContext();
  const today = new Date();
  
  // 获取今天的期权链
  const chain = await quote.optionChainInfoByDate(
    'QQQ.US', 
    new NaiveDate(today.getFullYear(), today.getMonth() + 1, today.getDate())
  );
  
  // 获取所有 Call 期权代码
  const callSymbols = chain
    .filter(opt => opt.callSymbol && opt.callSymbol.includes('C'))
    .map(opt => opt.callSymbol);
  
  console.log(`📡 获取 ${callSymbols.length} 个 Call 期权报价...`);
  
  // 获取实时报价
  const quotes = await quote.optionQuote(callSymbols);
  
  // 解析期权信息
  return quotes.map(q => ({
    symbol: q.symbol,
    lastPrice: parseFloat(q.lastDone) || 0,
    strike: q.symbol.match(/[CP](\d{6})\.US$/) ? 
      parseFloat(q.symbol.match(/[CP](\d{6})\.US$/)[1]) / 1000 : 0
  }));
}

// 下单函数
async function placeOrder(symbol, side, quantity, orderType) {
  const trade = await getTradeContext();
  
  const orderTypeMap = { 'MO': 3, 'LO': 1 };
  const sideMap = { 'Buy': 1, 'Sell': 2 };
  
  const orderParams = {
    symbol,
    orderType: orderTypeMap[orderType] || 0,
    side: sideMap[side] || 1,
    quantity: new Decimal(quantity.toString()),
    submittedQuantity: new Decimal(quantity.toString()),
    timeInForce: 1 // Day
  };
  
  try {
    const order = await trade.submitOrder(orderParams);
    console.log(`✅ 订单提交成功: ${side} ${symbol} x ${quantity}`);
    return order;
  } catch (error) {
    console.error(`❌ 订单提交失败: ${error.message}`);
    return null;
  }
}

// 每分钟检查一次
setInterval(runAutoTrading, 60000);

// 立即执行一次检查
runAutoTrading();

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
